import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { db, verifyPassword, hashPassword, AdminUser } from './db';

interface Session {
  userId: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'STAFF';
  createdAt: number;
  expiresAt: number;
}

// In-memory token store for authenticated admin sessions
const sessions = new Map<string, Session>();
// Rate limiting map for login attempts: ip -> { attempts, lockedUntil }
const loginAttempts = new Map<string, { count: number; lockedUntil?: number }>();

const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 mins

export function createSession(user: AdminUser): string {
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  sessions.set(token, {
    userId: user.id,
    role: user.role,
    createdAt: now,
    expiresAt: now + SESSION_TTL_MS,
  });
  return token;
}

export function revokeSession(token: string) {
  sessions.delete(token);
}

export function getSessionUser(req: Request): AdminUser | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.substring(7).trim();
  const session = sessions.get(token);
  if (!session) return null;

  if (Date.now() > session.expiresAt) {
    sessions.delete(token);
    return null;
  }

  const users = db.get('adminUsers');
  const user = users.find(u => u.id === session.userId && u.isActive);
  return user || null;
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = getSessionUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized: Session invalid or expired' });
  }
  (req as any).user = user;
  next();
}

export function requireRole(roles: Array<'SUPER_ADMIN' | 'ADMIN' | 'STAFF'>) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as AdminUser;
    if (!user || !roles.includes(user.role)) {
      return res.status(403).json({ error: 'Forbidden: Insufficient permissions' });
    }
    next();
  };
}

export function checkLoginRateLimit(ip: string): { allowed: boolean; remainingSeconds?: number } {
  const entry = loginAttempts.get(ip);
  if (!entry) return { allowed: true };

  const now = Date.now();
  if (entry.lockedUntil && entry.lockedUntil > now) {
    return {
      allowed: false,
      remainingSeconds: Math.ceil((entry.lockedUntil - now) / 1000),
    };
  }

  if (entry.lockedUntil && entry.lockedUntil <= now) {
    loginAttempts.delete(ip);
    return { allowed: true };
  }

  return { allowed: true };
}

export function recordFailedLogin(ip: string) {
  const now = Date.now();
  const entry = loginAttempts.get(ip) || { count: 0 };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = now + LOCKOUT_MS;
  }
  loginAttempts.set(ip, entry);
}

export function resetLoginAttempts(ip: string) {
  loginAttempts.delete(ip);
}
