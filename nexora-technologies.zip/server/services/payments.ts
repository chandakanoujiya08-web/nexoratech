import crypto from 'crypto';
import { db, Payment, Booking } from '../db';

export interface CreateOrderParams {
  bookingId?: string;
  customerId?: string;
  amount: number; // in INR
  currency?: string;
  receipt?: string;
}

export function createGatewayOrder(params: CreateOrderParams): { success: boolean; order?: any; error?: string } {
  const { bookingId, customerId, amount } = params;
  const settings = db.get('settings');

  if (amount <= 0) {
    return { success: false, error: 'Payment amount must be greater than zero.' };
  }

  // Generate unique order ID format matching Razorpay standard
  const orderId = `order_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  const nowStr = new Date().toISOString();

  let customerName = 'Customer';
  let serviceName = 'Nexora Service';

  if (bookingId) {
    const bookings = db.get('bookings');
    const b = bookings.find(item => item.id === bookingId);
    if (b) {
      customerName = b.customerName;
      serviceName = b.serviceName;
    }
  }

  const paymentRecord: Payment = {
    id: `pay_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    bookingId,
    customerId,
    customerName,
    serviceName,
    gateway: 'RAZORPAY',
    gatewayOrderId: orderId,
    amount,
    currency: 'INR',
    status: 'CREATED',
    signatureVerified: false,
    createdAt: nowStr,
    updatedAt: nowStr,
  };

  const payments = db.get('payments');
  payments.push(paymentRecord);
  db.set('payments', payments);

  db.logAudit({
    action: 'PAYMENT_ORDER_CREATED',
    entity: 'Payment',
    entityId: paymentRecord.id,
    metadata: { orderId, amount, bookingId },
  });

  return {
    success: true,
    order: {
      id: orderId,
      amount: amount * 100, // in paise
      currency: 'INR',
      keyId: settings.razorpayKeyId || 'rzp_test_nexora_demo',
      paymentId: paymentRecord.id,
    },
  };
}

export interface VerifyPaymentParams {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
  bookingId?: string;
}

export function verifyPaymentSignature(params: VerifyPaymentParams): { success: boolean; payment?: Payment; error?: string } {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, bookingId } = params;
  const payments = db.get('payments');
  const paymentIdx = payments.findIndex(p => p.gatewayOrderId === razorpay_order_id);

  if (paymentIdx === -1) {
    return { success: false, error: 'Payment order record not found in system.' };
  }

  const payment = payments[paymentIdx];

  // Idempotency: If already marked success, return it without duplicate mutation
  if (payment.status === 'SUCCESS' && payment.gatewayPaymentId === razorpay_payment_id) {
    return { success: true, payment };
  }

  const secret = process.env.RAZORPAY_KEY_SECRET;
  let signatureValid = false;

  if (secret) {
    const text = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expectedSignature = crypto.createHmac('sha256', secret).update(text).digest('hex');
    signatureValid = crypto.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(razorpay_signature));
  } else {
    // In test environment without production secret configured, verify that signature was provided
    signatureValid = Boolean(razorpay_signature && razorpay_signature.length >= 10);
  }

  if (!signatureValid) {
    payment.status = 'FAILED';
    payment.failureReason = 'Cryptographic signature mismatch on server verification';
    payment.updatedAt = new Date().toISOString();
    payments[paymentIdx] = payment;
    db.set('payments', payments);

    db.logAudit({
      action: 'PAYMENT_VERIFICATION_FAILED',
      entity: 'Payment',
      entityId: payment.id,
      metadata: { orderId: razorpay_order_id, reason: 'Invalid signature' },
    });

    return { success: false, error: 'Payment signature could not be verified by the server.' };
  }

  const nowStr = new Date().toISOString();
  payment.status = 'SUCCESS';
  payment.gatewayPaymentId = razorpay_payment_id;
  payment.signatureVerified = true;
  payment.paidAt = nowStr;
  payment.updatedAt = nowStr;
  payments[paymentIdx] = payment;
  db.set('payments', payments);

  // Update booking if attached
  if (payment.bookingId || bookingId) {
    const targetBookingId = payment.bookingId || bookingId;
    const bookings = db.get('bookings');
    const bIdx = bookings.findIndex(b => b.id === targetBookingId);
    if (bIdx !== -1) {
      bookings[bIdx] = {
        ...bookings[bIdx],
        status: 'CONFIRMED',
        paymentStatus: 'PAID',
        holdExpiresAt: undefined,
        updatedAt: nowStr,
      };
      db.set('bookings', bookings);
    } else {
      // Edge Case: Payment succeeded but booking was not found or was lost -> mark for admin reconciliation
      payment.status = 'SUCCESS';
      payments[paymentIdx] = payment;
      db.set('payments', payments);

      db.logAudit({
        action: 'PAYMENT_RECONCILIATION_ALERT',
        entity: 'Payment',
        entityId: payment.id,
        metadata: {
          note: 'Payment captured successfully, but associated booking record was missing.',
          orderId: razorpay_order_id,
          paymentId: razorpay_payment_id,
        },
      });
    }
  }

  db.logAudit({
    action: 'PAYMENT_SUCCESS',
    entity: 'Payment',
    entityId: payment.id,
    metadata: {
      orderId: razorpay_order_id,
      paymentId: razorpay_payment_id,
      amount: payment.amount,
    },
  });

  return { success: true, payment };
}

export function processRefund(paymentId: string, amount?: number, reason?: string) {
  const payments = db.get('payments');
  const idx = payments.findIndex(p => p.id === paymentId);
  if (idx === -1) return { success: false, error: 'Payment record not found.' };

  const payment = payments[idx];
  if (payment.status !== 'SUCCESS') {
    return { success: false, error: 'Only successful payments can be refunded.' };
  }

  const refundAmt = amount || payment.amount;
  if (refundAmt > payment.amount) {
    return { success: false, error: 'Refund amount cannot exceed captured payment amount.' };
  }

  const isPartial = refundAmt < payment.amount;
  payment.status = isPartial ? 'PARTIALLY_REFUNDED' : 'REFUNDED';
  payment.refundAmount = refundAmt;
  payment.refundedAt = new Date().toISOString();
  payment.updatedAt = new Date().toISOString();
  payments[idx] = payment;
  db.set('payments', payments);

  if (payment.bookingId) {
    const bookings = db.get('bookings');
    const bIdx = bookings.findIndex(b => b.id === payment.bookingId);
    if (bIdx !== -1) {
      bookings[bIdx] = {
        ...bookings[bIdx],
        paymentStatus: 'REFUNDED',
        updatedAt: new Date().toISOString(),
      };
      db.set('bookings', bookings);
    }
  }

  db.logAudit({
    action: isPartial ? 'PAYMENT_PARTIALLY_REFUNDED' : 'PAYMENT_REFUNDED',
    entity: 'Payment',
    entityId: payment.id,
    metadata: { refundAmount: refundAmt, reason },
  });

  return { success: true, payment };
}
