import { db, Lead } from '../db';

export interface SheetsSyncResult {
  success: boolean;
  message: string;
  syncedCount?: number;
  unconnected?: boolean;
}

export async function syncLeadToGoogleSheets(lead: Lead): Promise<SheetsSyncResult> {
  const settings = db.get('settings');
  
  if (!settings.googleSheetsConnected || !settings.googleSheetId) {
    return {
      success: false,
      message: 'GOOGLE SHEETS NOT CONNECTED',
      unconnected: true,
    };
  }

  try {
    // If webhook or Google Sheets API configured via environment variable
    const webhookUrl = process.env.GOOGLE_SHEETS_WEBHOOK_URL;
    if (webhookUrl) {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sheetId: settings.googleSheetId,
          leadId: lead.id,
          name: lead.name,
          phone: lead.phone,
          whatsapp: lead.whatsapp,
          email: lead.email,
          business: lead.companyName || '',
          service: lead.serviceName || lead.serviceId,
          requirements: lead.requirements,
          budget: lead.budget,
          timeline: lead.timeline,
          source: lead.source,
          date: lead.createdAt,
          status: lead.status,
        }),
      });

      if (!response.ok) {
        throw new Error(`Sheets sync endpoint responded with status ${response.status}`);
      }
    } else {
      // If service credentials are not provided in environment, do not fabricate success!
      return {
        success: false,
        message: 'GOOGLE SHEETS NOT CONNECTED (Missing GOOGLE_SHEETS_WEBHOOK_URL or API credentials in environment)',
        unconnected: true,
      };
    }

    // Update lead record
    const leads = db.get('leads');
    const idx = leads.findIndex(l => l.id === lead.id);
    if (idx !== -1) {
      leads[idx].syncedToSheets = true;
      leads[idx].sheetsSyncedAt = new Date().toISOString();
      db.set('leads', leads);
    }

    db.logAudit({
      action: 'LEAD_SYNCED_TO_SHEETS',
      entity: 'Lead',
      entityId: lead.id,
      metadata: { sheetId: settings.googleSheetId },
    });

    return { success: true, message: 'Lead synchronized to Google Sheets successfully.' };
  } catch (error: any) {
    db.logAudit({
      action: 'LEAD_SYNC_TO_SHEETS_FAILED',
      entity: 'Lead',
      entityId: lead.id,
      metadata: { error: error.message },
    });

    return {
      success: false,
      message: `Failed to synchronize with Google Sheets: ${error.message}`,
    };
  }
}
