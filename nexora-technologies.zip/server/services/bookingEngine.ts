import crypto from 'crypto';
import { db, Booking, Customer } from '../db';

export const BUSINESS_SLOTS = [
  '09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'
];

export interface AvailabilitySlot {
  time: string;
  available: boolean;
  reason?: 'BOOKED' | 'HELD' | 'PAST';
}

// Clean up expired slot holds (e.g. held > 15 minutes without payment completion)
export function pruneExpiredHolds() {
  const bookings = db.get('bookings');
  const now = new Date();
  let modified = false;

  const updated = bookings.map(b => {
    if (b.status === 'PENDING' && b.paymentStatus === 'HELD' && b.holdExpiresAt) {
      if (new Date(b.holdExpiresAt) < now) {
        modified = true;
        return {
          ...b,
          status: 'EXPIRED' as const,
          paymentStatus: 'UNPAID' as const,
          updatedAt: now.toISOString(),
        };
      }
    }
    return b;
  });

  if (modified) {
    db.set('bookings', updated);
  }
}

export function getAvailableSlotsForDate(dateStr: string): AvailabilitySlot[] {
  pruneExpiredHolds();
  const bookings = db.get('bookings');
  const now = new Date();

  // Validate format YYYY-MM-DD
  const targetDate = new Date(`${dateStr}T00:00:00+05:30`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isPastDay = targetDate < today;

  return BUSINESS_SLOTS.map(slotTime => {
    if (isPastDay) {
      return { time: slotTime, available: false, reason: 'PAST' };
    }

    // Check if slot time on today is already past
    const [h, m] = slotTime.split(':').map(Number);
    const slotDateTime = new Date(`${dateStr}T${slotTime}:00+05:30`);
    if (slotDateTime <= now) {
      return { time: slotTime, available: false, reason: 'PAST' };
    }

    // Check active conflicting booking on that date and time
    const conflict = bookings.find(b => {
      if (b.date !== dateStr || b.startTime !== slotTime) return false;
      // Confirmed, rescheduled, or currently held within payment window
      if (b.status === 'CONFIRMED' || b.status === 'RESCHEDULED') return true;
      if (b.status === 'PENDING' && b.paymentStatus === 'HELD' && b.holdExpiresAt) {
        return new Date(b.holdExpiresAt) > now;
      }
      return false;
    });

    if (conflict) {
      const reason = conflict.paymentStatus === 'HELD' ? 'HELD' : 'BOOKED';
      return { time: slotTime, available: false, reason };
    }

    return { time: slotTime, available: true };
  });
}

export interface CreateBookingParams {
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  serviceId: string;
  date: string;
  startTime: string;
  requirements: string;
  companyName?: string;
  advancePaymentRequired?: boolean;
}

export function createBooking(params: CreateBookingParams): { success: boolean; booking?: Booking; error?: string } {
  pruneExpiredHolds();

  const { name, phone, whatsapp, email, serviceId, date, startTime, requirements, companyName, advancePaymentRequired } = params;

  // Validation
  if (!name?.trim() || !phone?.trim() || !email?.trim() || !date?.trim() || !startTime?.trim() || !serviceId?.trim()) {
    return { success: false, error: 'All mandatory fields (name, phone, email, service, date, time) must be provided.' };
  }

  // Find service
  const services = db.get('services');
  const service = services.find(s => s.id === serviceId && s.isActive);
  if (!service) {
    return { success: false, error: 'The selected service is invalid or currently inactive.' };
  }

  // Verify slot is currently free (Race condition protection: single-threaded JS event loop ensures atomic check & write)
  const availableSlots = getAvailableSlotsForDate(date);
  const selectedSlot = availableSlots.find(s => s.time === startTime);

  if (!selectedSlot || !selectedSlot.available) {
    return {
      success: false,
      error: `The requested consultation slot at ${startTime} on ${date} is no longer available. Please select another slot.`,
    };
  }

  // Calculate 1 hour duration
  const [h, m] = startTime.split(':').map(Number);
  const endHour = (h + 1).toString().padStart(2, '0');
  const endTime = `${endHour}:${m.toString().padStart(2, '0')}`;

  // Find or create customer record
  let customers = db.get('customers');
  let customer = customers.find(c => c.email.toLowerCase() === email.toLowerCase() || c.phone === phone);
  const nowStr = new Date().toISOString();

  if (!customer) {
    customer = {
      id: `cust_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
      name: name.trim(),
      phone: phone.trim(),
      whatsapp: (whatsapp || phone).trim(),
      email: email.trim().toLowerCase(),
      companyName: companyName?.trim() || '',
      city: 'Vapi',
      state: 'Gujarat',
      country: 'India',
      createdAt: nowStr,
      updatedAt: nowStr,
    };
    customers.push(customer);
    db.set('customers', customers);
  }

  const bookingRef = `NEX-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
  const isHeldForPayment = Boolean(advancePaymentRequired);
  const holdExpires = isHeldForPayment ? new Date(Date.now() + 15 * 60 * 1000).toISOString() : undefined;

  const newBooking: Booking = {
    id: `bk_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    customerId: customer.id,
    customerName: customer.name,
    customerPhone: customer.phone,
    customerWhatsApp: customer.whatsapp,
    customerEmail: customer.email,
    serviceId: service.id,
    serviceName: service.name,
    bookingReference: bookingRef,
    date,
    startTime,
    endTime,
    timezone: 'Asia/Kolkata',
    status: isHeldForPayment ? 'PENDING' : 'CONFIRMED',
    requirements: requirements?.trim() || 'General consultation request',
    paymentStatus: isHeldForPayment ? 'HELD' : 'UNPAID',
    paymentAmount: service.price,
    holdExpiresAt: holdExpires,
    createdAt: nowStr,
    updatedAt: nowStr,
  };

  const bookings = db.get('bookings');
  bookings.push(newBooking);
  db.set('bookings', bookings);

  // Auto-create lead in CRM
  const leads = db.get('leads');
  const newLead = {
    id: `lead_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    customerId: customer.id,
    name: customer.name,
    phone: customer.phone,
    whatsapp: customer.whatsapp,
    email: customer.email,
    companyName: customer.companyName,
    serviceId: service.id,
    serviceName: service.name,
    source: 'CONSULTATION_BOOKING',
    requirements: newBooking.requirements,
    budget: `₹${service.price.toLocaleString('en-IN')}`,
    timeline: service.duration,
    status: 'CONSULTATION' as const,
    notes: `Booked consultation on ${date} at ${startTime} (Ref: ${bookingRef})`,
    syncedToSheets: false,
    createdAt: nowStr,
    updatedAt: nowStr,
  };
  leads.push(newLead);
  db.set('leads', leads);

  db.logAudit({
    action: 'BOOKING_CREATED',
    entity: 'Booking',
    entityId: newBooking.id,
    metadata: {
      bookingReference: bookingRef,
      customerEmail: customer.email,
      date,
      startTime,
      serviceName: service.name,
    },
  });

  return { success: true, booking: newBooking };
}

export function rescheduleBooking(bookingId: string, newDate: string, newStartTime: string, reason?: string) {
  pruneExpiredHolds();
  const bookings = db.get('bookings');
  const idx = bookings.findIndex(b => b.id === bookingId);
  if (idx === -1) return { success: false, error: 'Booking not found.' };

  const booking = bookings[idx];
  if (['CANCELLED', 'COMPLETED', 'EXPIRED'].includes(booking.status)) {
    return { success: false, error: `Cannot reschedule a booking that is currently ${booking.status.toLowerCase()}.` };
  }

  // Check if new slot is available
  const availableSlots = getAvailableSlotsForDate(newDate);
  const targetSlot = availableSlots.find(s => s.time === newStartTime);
  if (!targetSlot || !targetSlot.available) {
    return { success: false, error: 'The newly requested date or time slot is not available.' };
  }

  const [h, m] = newStartTime.split(':').map(Number);
  const endHour = (h + 1).toString().padStart(2, '0');
  const endTime = `${endHour}:${m.toString().padStart(2, '0')}`;

  const oldDate = booking.date;
  const oldTime = booking.startTime;

  bookings[idx] = {
    ...booking,
    date: newDate,
    startTime: newStartTime,
    endTime,
    status: 'RESCHEDULED',
    notes: (booking.notes ? booking.notes + '\n' : '') + `Rescheduled from ${oldDate} ${oldTime} to ${newDate} ${newStartTime}. Reason: ${reason || 'Customer request'}`,
    updatedAt: new Date().toISOString(),
  };

  db.set('bookings', bookings);

  db.logAudit({
    action: 'BOOKING_RESCHEDULED',
    entity: 'Booking',
    entityId: booking.id,
    metadata: { oldDate, oldTime, newDate, newStartTime, reason },
  });

  return { success: true, booking: bookings[idx] };
}

export function cancelBooking(bookingId: string, reason: string, cancelledByAdmin = false) {
  const bookings = db.get('bookings');
  const idx = bookings.findIndex(b => b.id === bookingId);
  if (idx === -1) return { success: false, error: 'Booking not found.' };

  const booking = bookings[idx];
  if (booking.status === 'CANCELLED') {
    return { success: false, error: 'Booking is already cancelled.' };
  }

  bookings[idx] = {
    ...booking,
    status: 'CANCELLED',
    cancellationReason: reason,
    updatedAt: new Date().toISOString(),
  };

  db.set('bookings', bookings);

  db.logAudit({
    action: 'BOOKING_CANCELLED',
    entity: 'Booking',
    entityId: booking.id,
    metadata: { reason, cancelledByAdmin },
  });

  return { success: true, booking: bookings[idx] };
}
