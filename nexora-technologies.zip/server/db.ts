import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  salt: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'STAFF';
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  companyName?: string;
  address?: string;
  city: string;
  state: string;
  country: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Lead {
  id: string;
  customerId?: string;
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  companyName?: string;
  serviceId: string;
  serviceName?: string;
  source: string;
  requirements: string;
  budget: string;
  timeline: string;
  status: 'NEW' | 'CONTACTED' | 'CONSULTATION' | 'PROPOSAL' | 'NEGOTIATION' | 'WON' | 'LOST';
  notes?: string;
  assignedTo?: string;
  syncedToSheets?: boolean;
  sheetsSyncedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Service {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  currency: string;
  pricingType: 'ONE_TIME' | 'MONTHLY' | 'CUSTOM';
  duration: string;
  isActive: boolean;
  sortOrder: number;
  features?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerWhatsApp: string;
  customerEmail: string;
  serviceId: string;
  serviceName: string;
  bookingReference: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  timezone: string;
  status: 'PENDING' | 'CONFIRMED' | 'RESCHEDULED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW' | 'EXPIRED';
  requirements: string;
  notes?: string;
  paymentStatus: 'UNPAID' | 'HELD' | 'PAID' | 'REFUNDED' | 'RECONCILIATION_REQUIRED';
  paymentAmount: number;
  holdExpiresAt?: string; // ISO String for 15-minute checkout lock
  cancellationReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  bookingId?: string;
  customerId?: string;
  customerName?: string;
  serviceName?: string;
  gateway: 'RAZORPAY' | 'MANUAL';
  gatewayOrderId: string;
  gatewayPaymentId?: string;
  amount: number;
  currency: string;
  status: 'CREATED' | 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED' | 'CANCELLED';
  paymentMethod?: string;
  failureReason?: string;
  paidAt?: string;
  refundedAt?: string;
  refundAmount?: number;
  signatureVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio?: string;
  photo?: string;
  skills: string[];
  socialLinks: { [key: string]: string };
  sortOrder: number;
  isActive: boolean;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  sortOrder: number;
  isPublished: boolean;
}

export interface Review {
  id: string;
  source: string;
  reviewerName: string;
  rating: number;
  reviewText: string;
  reviewUrl?: string;
  isVerified: boolean;
  isPublished: boolean;
  createdAt: string;
}

export interface WebsiteContent {
  id: string;
  section: string;
  key: string;
  value: string;
  type: 'TEXT' | 'MARKDOWN' | 'JSON' | 'BOOLEAN';
  updatedBy?: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  adminUserId?: string;
  adminUserName?: string;
  action: string;
  entity: string;
  entityId?: string;
  metadata?: any;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export interface AnalyticsEvent {
  id: string;
  event: string;
  path: string;
  metadata?: any;
  timestamp: string;
}

export interface SystemSettings {
  businessName: string;
  positioning: string;
  phone: string;
  whatsapp: string;
  email: string;
  location: string;
  exactAddressVerified: boolean;
  exactAddress?: string;
  businessHours: string;
  foundedYear: number;
  timezone: string;
  razorpayKeyId?: string;
  razorpayKeySecretConfigured: boolean;
  googleSheetsConnected: boolean;
  googleSheetId?: string;
  bookingAdvanceRequired: boolean;
  bookingAdvanceAmount: number;
}

export interface DatabaseSchema {
  adminUsers: AdminUser[];
  customers: Customer[];
  leads: Lead[];
  services: Service[];
  bookings: Booking[];
  payments: Payment[];
  teamMembers: TeamMember[];
  faqs: FAQ[];
  reviews: Review[];
  websiteContent: WebsiteContent[];
  auditLogs: AuditLog[];
  analyticsEvents: AnalyticsEvent[];
  settings: SystemSettings;
  checklistState: { [key: string]: 'NOT STARTED' | 'IN PROGRESS' | 'COMPLETED' | 'NEEDS REVIEW' };
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'database.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Helpers for secure password hashing using Node scrypt
export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(derived, 'utf-8'), Buffer.from(hash, 'utf-8'));
}

// Initial seed conforming strictly to prompt specifications
function getInitialData(): DatabaseSchema {
  const adminPass = hashPassword('NexoraAdmin2026!');
  
  return {
    adminUsers: [
      {
        id: 'usr_superadmin_01',
        name: 'Vansh',
        email: 'vanitakanojia25@gmail.com',
        passwordHash: adminPass.hash,
        salt: adminPass.salt,
        role: 'SUPER_ADMIN',
        isActive: true,
        lastLoginAt: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    customers: [],
    leads: [],
    services: [
      {
        id: 'srv_web_dev',
        name: 'Web Development',
        slug: 'web-development',
        description: 'Bespoke high-performance responsive web applications built with modern frameworks, high-speed architectures, and conversion-focused architecture.',
        price: 2999,
        currency: 'INR',
        pricingType: 'ONE_TIME',
        duration: '7 - 14 Business Days',
        isActive: true,
        sortOrder: 1,
        features: [
          'Custom responsive design & clean typography',
          'Fast performance & Core Web Vitals optimization',
          'Modern React/TypeScript engineering',
          'Technical SEO & OpenGraph implementation',
          'Contact & lead capture integration',
          '30 days post-launch warranty support',
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'srv_app_dev',
        name: 'App Development',
        slug: 'app-development',
        description: 'End-to-end mobile application development for Android & iOS with smooth touch interactions, secure data handling, and scalable backend services.',
        price: 7999,
        currency: 'INR',
        pricingType: 'ONE_TIME',
        duration: '14 - 28 Business Days',
        isActive: true,
        sortOrder: 2,
        features: [
          'Cross-platform responsive mobile architecture',
          'Native hardware integration & push notifications',
          'Secure offline caching & state synchronization',
          'Modern component design system',
          'API integration & authentication flow',
          'App store preparation & launch support',
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'srv_web_ins',
        name: 'Web Insurance',
        slug: 'web-insurance',
        description: 'Comprehensive digital security, dependency updates, uptime monitoring, bug fixes, and critical emergency patch protection for web applications.',
        price: 499,
        currency: 'INR',
        pricingType: 'ONE_TIME',
        duration: 'One-Time Protection Package',
        isActive: true,
        sortOrder: 3,
        features: [
          'Comprehensive security audit & header hardening',
          'SSL & DNS health verification',
          'Database backup & recovery verification',
          'Core security patch updates',
          'Emergency bug resolution coverage',
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'srv_app_ins',
        name: 'App Insurance',
        slug: 'app-insurance',
        description: 'Dedicated stability assurance, OS compatibility audits, crash tracking, and vulnerability patching for deployed mobile applications.',
        price: 999,
        currency: 'INR',
        pricingType: 'ONE_TIME',
        duration: 'One-Time Protection Package',
        isActive: true,
        sortOrder: 4,
        features: [
          'OS version compatibility audit',
          'Security vulnerability scanning',
          'Crash telemetry diagnosis',
          'Package & SDK dependency updates',
          'Critical incident recovery support',
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'srv_meta_ads',
        name: 'Meta Ads',
        slug: 'meta-ads',
        description: 'Data-driven Meta advertising campaigns designed to target qualified customers across Facebook and Instagram with high-conversion creative funnels.',
        price: 20000,
        currency: 'INR',
        pricingType: 'ONE_TIME',
        duration: 'Monthly Campaign Architecture',
        isActive: true,
        sortOrder: 5,
        features: [
          'Target audience research & segmentation',
          'High-intent creative ad copywriting',
          'Meta Pixel & Conversion API setup',
          'A/B test creative experimentation',
          'Weekly performance audits & optimization',
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    bookings: [],
    payments: [],
    // Team member information STRICTLY as supplied by user:
    // Vansh — Owner, Mayank — Coder, Aradhya — Designer, Sorta — Manager, Vivian — Marketer
    teamMembers: [
      {
        id: 'team_01',
        name: 'Vansh',
        role: 'Owner',
        bio: 'Leading strategic vision, client partnerships, and technical direction for Nexora Technologies.',
        skills: ['Business Strategy', 'Technical Architecture', 'Client Partnerships'],
        socialLinks: {},
        sortOrder: 1,
        isActive: true,
      },
      {
        id: 'team_02',
        name: 'Mayank',
        role: 'Coder',
        bio: 'Engineering robust frontend, backend APIs, and reliable database architectures.',
        skills: ['Web & App Engineering', 'Node.js', 'React', 'System Design'],
        socialLinks: {},
        sortOrder: 2,
        isActive: true,
      },
      {
        id: 'team_03',
        name: 'Aradhya',
        role: 'Designer',
        bio: 'Crafting user-centered interfaces, visual design systems, and digital product experiences.',
        skills: ['UI/UX Design', 'Design Systems', 'Interaction Design', 'Typography'],
        socialLinks: {},
        sortOrder: 3,
        isActive: true,
      },
      {
        id: 'team_04',
        name: 'Sorta',
        role: 'Manager',
        bio: 'Orchestrating project workflows, delivery timelines, and client communications.',
        skills: ['Project Management', 'Workflow Coordination', 'Quality Assurance'],
        socialLinks: {},
        sortOrder: 4,
        isActive: true,
      },
      {
        id: 'team_05',
        name: 'Vivian',
        role: 'Marketer',
        bio: 'Driving growth strategies, campaign execution, and digital audience engagement.',
        skills: ['Digital Marketing', 'Paid Acquisition', 'Campaign Analytics'],
        socialLinks: {},
        sortOrder: 5,
        isActive: true,
      },
    ],
    faqs: [
      {
        id: 'faq_01',
        category: 'Services',
        question: 'What types of solutions does Nexora Technologies build?',
        answer: 'We specialize in custom web development, mobile applications, technical security packages (Web & App Insurance), and targeted Meta Ads campaigns designed for startups, businesses, and organizations.',
        sortOrder: 1,
        isPublished: true,
      },
      {
        id: 'faq_02',
        category: 'Pricing',
        question: 'Are there any hidden costs beyond the displayed pricing?',
        answer: 'No. Our pricing is completely transparent: Web Development is ₹2,999, App Development is ₹7,999, Web Insurance is ₹499, App Insurance is ₹999, and Meta Ads is ₹20,000. Third-party hosting, domains, or ad spend budgets are paid directly to your chosen providers.',
        sortOrder: 2,
        isPublished: true,
      },
      {
        id: 'faq_03',
        category: 'Booking',
        question: 'How does the consultation and booking process work?',
        answer: 'You can book a 1-on-1 consultation slot through our real-time calendar system. You select your required service, preferred date, and time. Slots are held and locked to guarantee no double-booking.',
        sortOrder: 3,
        isPublished: true,
      },
      {
        id: 'faq_04',
        category: 'Location',
        question: 'Where is Nexora Technologies located?',
        answer: 'Nexora Technologies was founded in 2026 and is headquartered in Vapi, Gujarat, India. We collaborate with clients locally in Gujarat as well as across India and internationally.',
        sortOrder: 4,
        isPublished: true,
      },
      {
        id: 'faq_05',
        category: 'Contact',
        question: 'How quickly can I reach the team?',
        answer: 'Our business operates 24 hours. You can message our business WhatsApp at +91 99248 82026, call +91 99248 84026, or email us at vanitakanojia25@gmail.com.',
        sortOrder: 5,
        isPublished: true,
      },
    ],
    // STRICT RULE: No fake reviews!
    reviews: [],
    websiteContent: [
      {
        id: 'content_hero_tagline',
        section: 'Hero',
        key: 'headline',
        value: 'INNOVATING WEB & APP SOLUTIONS FOR TOMORROW.',
        type: 'TEXT',
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'content_hero_sub',
        section: 'Hero',
        key: 'subheadline',
        value: 'Engineering bespoke, high-performance web applications and mobile platforms for ambitious businesses and founders.',
        type: 'TEXT',
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'content_contact_location',
        section: 'Contact',
        key: 'location_text',
        value: 'Vapi, Gujarat, India',
        type: 'TEXT',
        updatedAt: new Date().toISOString(),
      },
    ],
    auditLogs: [
      {
        id: 'audit_init',
        action: 'SYSTEM_INITIALIZED',
        entity: 'System',
        metadata: { version: '1.0.0', initializedAt: new Date().toISOString() },
        createdAt: new Date().toISOString(),
      },
    ],
    analyticsEvents: [],
    settings: {
      businessName: 'Nexora Technologies',
      positioning: 'Innovating Web and App Solutions for Tomorrow.',
      phone: '+91 99248 84026',
      whatsapp: '+91 99248 82026',
      email: 'vanitakanojia25@gmail.com',
      location: 'Vapi, Gujarat, India',
      exactAddressVerified: false,
      exactAddress: '',
      businessHours: '24 Hours',
      foundedYear: 2026,
      timezone: 'Asia/Kolkata',
      razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
      razorpayKeySecretConfigured: Boolean(process.env.RAZORPAY_KEY_SECRET),
      googleSheetsConnected: false,
      googleSheetId: '',
      bookingAdvanceRequired: false,
      bookingAdvanceAmount: 499,
    },
    checklistState: {
      'Business name verified': 'COMPLETED',
      'Location verified': 'COMPLETED',
      'Phone verified': 'COMPLETED',
      'WhatsApp verified': 'COMPLETED',
      'Email verified': 'COMPLETED',
      'Business hours verified': 'COMPLETED',
      'Logo & brand verified': 'COMPLETED',
      'Services verified': 'COMPLETED',
      'Prices verified': 'COMPLETED',
      'Team verified': 'COMPLETED',
      'No fake claims': 'COMPLETED',
      'Accessibility tested': 'IN PROGRESS',
      'Security headers checked': 'IN PROGRESS',
      'Google Sheets tested': 'NOT STARTED',
      'Payment gateway verified': 'NOT STARTED',
      'Final owner approval': 'NEEDS REVIEW',
    },
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Failed to load database.json, initializing fresh seed:', e);
    }
    const fresh = getInitialData();
    this.persistSync(fresh);
    return fresh;
  }

  private persistSync(dataToSave: DatabaseSchema) {
    try {
      const tempPath = `${DB_PATH}.tmp.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_PATH);
    } catch (e) {
      console.error('Failed to persist database:', e);
    }
  }

  public get<K extends keyof DatabaseSchema>(key: K): DatabaseSchema[K] {
    return this.data[key];
  }

  public set<K extends keyof DatabaseSchema>(key: K, value: DatabaseSchema[K]) {
    this.data[key] = value;
    this.persistSync(this.data);
  }

  public logAudit(log: Omit<AuditLog, 'id' | 'createdAt'>) {
    const entry: AuditLog = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      ...log,
      createdAt: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(entry);
    // Keep max 500 audit logs
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    this.persistSync(this.data);
    return entry;
  }

  public logAnalytics(event: string, path: string, metadata?: any) {
    const entry: AnalyticsEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      event,
      path,
      metadata,
      timestamp: new Date().toISOString(),
    };
    this.data.analyticsEvents.unshift(entry);
    if (this.data.analyticsEvents.length > 1000) {
      this.data.analyticsEvents = this.data.analyticsEvents.slice(0, 1000);
    }
    this.persistSync(this.data);
    return entry;
  }
}

export const db = new Database();
