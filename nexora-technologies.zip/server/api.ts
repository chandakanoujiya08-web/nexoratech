import express, { Request, Response } from 'express';
import crypto from 'crypto';
import { db, verifyPassword, hashPassword, Service, Lead, Booking } from './db';
import {
  createSession,
  revokeSession,
  requireAuth,
  requireRole,
  checkLoginRateLimit,
  recordFailedLogin,
  resetLoginAttempts,
  getSessionUser,
} from './auth';
import {
  getAvailableSlotsForDate,
  createBooking,
  rescheduleBooking,
  cancelBooking,
} from './services/bookingEngine';
import {
  createGatewayOrder,
  verifyPaymentSignature,
  processRefund,
} from './services/payments';
import { syncLeadToGoogleSheets } from './services/sheets';

export const apiRouter = express.Router();

// -------------------------------------------------------------
// PUBLIC ENDPOINTS
// -------------------------------------------------------------

apiRouter.get('/public/info', (req: Request, res: Response) => {
  const settings = db.get('settings');
  const services = db.get('services').filter(s => s.isActive).sort((a, b) => a.sortOrder - b.sortOrder);
  const teamMembers = db.get('teamMembers').filter(t => t.isActive).sort((a, b) => a.sortOrder - b.sortOrder);
  const faqs = db.get('faqs').filter(f => f.isPublished).sort((a, b) => a.sortOrder - b.sortOrder);
  const reviews = db.get('reviews').filter(r => r.isPublished && r.isVerified);
  const websiteContent = db.get('websiteContent');

  res.json({
    business: {
      name: settings.businessName,
      positioning: settings.positioning,
      foundedYear: settings.foundedYear,
      location: settings.location,
      exactAddress: settings.exactAddressVerified ? settings.exactAddress : null,
      phone: settings.phone,
      whatsapp: settings.whatsapp,
      email: settings.email,
      businessHours: settings.businessHours,
      bookingAdvanceRequired: settings.bookingAdvanceRequired,
      bookingAdvanceAmount: settings.bookingAdvanceAmount,
    },
    services,
    teamMembers,
    faqs,
    reviews,
    websiteContent,
  });
});

apiRouter.get('/public/availability', (req: Request, res: Response) => {
  const date = req.query.date as string;
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ error: 'Valid date parameter in YYYY-MM-DD format is required.' });
  }

  const slots = getAvailableSlotsForDate(date);
  res.json({ date, slots, timezone: 'Asia/Kolkata' });
});

apiRouter.post('/public/book', (req: Request, res: Response) => {
  const { name, phone, whatsapp, email, serviceId, date, startTime, requirements, companyName, advancePaymentRequired } = req.body;
  const result = createBooking({
    name,
    phone,
    whatsapp,
    email,
    serviceId,
    date,
    startTime,
    requirements,
    companyName,
    advancePaymentRequired,
  });

  if (!result.success) {
    return res.status(409).json({ error: result.error });
  }

  res.status(201).json({
    success: true,
    booking: result.booking,
    message: result.booking?.paymentStatus === 'HELD'
      ? 'Slot temporarily reserved. Please complete payment within 15 minutes.'
      : 'Consultation booking confirmed successfully.',
  });
});

apiRouter.post('/public/quote', async (req: Request, res: Response) => {
  const { name, phone, whatsapp, email, business, serviceId, requirements, budget, timeline } = req.body;

  if (!name?.trim() || !phone?.trim() || !email?.trim() || !requirements?.trim()) {
    return res.status(400).json({ error: 'Name, phone, email, and requirements are mandatory.' });
  }

  const services = db.get('services');
  const service = services.find(s => s.id === serviceId);
  const serviceName = service ? service.name : (serviceId || 'General Web/App Inquiry');

  const nowStr = new Date().toISOString();
  const leads = db.get('leads');
  const newLead: Lead = {
    id: `lead_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    name: name.trim(),
    phone: phone.trim(),
    whatsapp: (whatsapp || phone).trim(),
    email: email.trim().toLowerCase(),
    companyName: business?.trim() || '',
    serviceId: serviceId || 'custom',
    serviceName,
    source: 'QUOTE_REQUEST',
    requirements: requirements.trim(),
    budget: budget?.trim() || 'Standard Pricing',
    timeline: timeline?.trim() || 'Flexible',
    status: 'NEW',
    syncedToSheets: false,
    createdAt: nowStr,
    updatedAt: nowStr,
  };

  leads.push(newLead);
  db.set('leads', leads);

  // Attempt sync to sheets if configured
  const syncResult = await syncLeadToGoogleSheets(newLead);

  db.logAudit({
    action: 'QUOTE_SUBMITTED',
    entity: 'Lead',
    entityId: newLead.id,
    metadata: { name: newLead.name, service: serviceName, sheetsSync: syncResult.message },
  });

  // Pre-fill WhatsApp message URL
  const settings = db.get('settings');
  const cleanPhone = settings.whatsapp.replace(/[^\d]/g, '');
  const encodedMsg = encodeURIComponent(
    `Hello Nexora Technologies, I submitted a project quote request on your website for ${serviceName}. My name is ${name}.`
  );
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodedMsg}`;

  res.status(201).json({
    success: true,
    message: 'Thank you. Your project quote request has been received. Our team will review your specifications promptly.',
    leadId: newLead.id,
    whatsappUrl,
    sheetsStatus: syncResult.message,
  });
});

apiRouter.post('/public/contact', (req: Request, res: Response) => {
  const { name, phone, email, message, subject } = req.body;
  if (!name?.trim() || !email?.trim() || !message?.trim()) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }

  const nowStr = new Date().toISOString();
  const leads = db.get('leads');
  const newLead: Lead = {
    id: `lead_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    name: name.trim(),
    phone: phone?.trim() || '',
    whatsapp: phone?.trim() || '',
    email: email.trim().toLowerCase(),
    serviceId: 'contact_form',
    serviceName: subject?.trim() || 'General Inquiry',
    source: 'CONTACT_FORM',
    requirements: message.trim(),
    budget: 'N/A',
    timeline: 'Immediate',
    status: 'NEW',
    syncedToSheets: false,
    createdAt: nowStr,
    updatedAt: nowStr,
  };

  leads.push(newLead);
  db.set('leads', leads);

  db.logAudit({
    action: 'CONTACT_MESSAGE_RECEIVED',
    entity: 'Lead',
    entityId: newLead.id,
    metadata: { name, email },
  });

  res.status(201).json({
    success: true,
    message: 'Your message has been delivered to Nexora Technologies. We operate 24 hours and will respond shortly.',
  });
});

apiRouter.post('/public/reschedule', (req: Request, res: Response) => {
  const { bookingReference, date, startTime, reason } = req.body;
  if (!bookingReference || !date || !startTime) {
    return res.status(400).json({ error: 'Booking reference, new date, and new start time are required.' });
  }

  const bookings = db.get('bookings');
  const booking = bookings.find(b => b.bookingReference.trim().toUpperCase() === bookingReference.trim().toUpperCase());
  if (!booking) {
    return res.status(404).json({ error: 'Booking with the provided reference number was not found.' });
  }

  const result = rescheduleBooking(booking.id, date, startTime, reason);
  if (!result.success) {
    return res.status(409).json({ error: result.error });
  }

  res.json({
    success: true,
    message: 'Booking rescheduled successfully.',
    booking: result.booking,
  });
});

apiRouter.post('/public/cancel', (req: Request, res: Response) => {
  const { bookingReference, reason } = req.body;
  if (!bookingReference) {
    return res.status(400).json({ error: 'Booking reference is required.' });
  }

  const bookings = db.get('bookings');
  const booking = bookings.find(b => b.bookingReference.trim().toUpperCase() === bookingReference.trim().toUpperCase());
  if (!booking) {
    return res.status(404).json({ error: 'Booking with the provided reference was not found.' });
  }

  const result = cancelBooking(booking.id, reason || 'Customer requested cancellation via portal');
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }

  res.json({
    success: true,
    message: 'Booking has been cancelled.',
    booking: result.booking,
  });
});

// Payments
apiRouter.post('/payments/create-order', (req: Request, res: Response) => {
  const { bookingId, customerId, amount } = req.body;
  const result = createGatewayOrder({ bookingId, customerId, amount: Number(amount) });
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }
  res.json(result);
});

apiRouter.post('/payments/verify', (req: Request, res: Response) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, bookingId } = req.body;
  if (!razorpay_order_id || !razorpay_payment_id) {
    return res.status(400).json({ error: 'Order ID and Payment ID are required for verification.' });
  }

  const result = verifyPaymentSignature({
    razorpay_order_id,
    razorpay_payment_id,
    razorpay_signature: razorpay_signature || '',
    bookingId,
  });

  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }

  res.json({
    success: true,
    message: 'Payment verified and captured successfully.',
    payment: result.payment,
  });
});

// Razorpay Webhook (idempotent signature check)
apiRouter.post('/payments/webhook', (req: Request, res: Response) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.headers['x-razorpay-signature'] as string;

  if (secret && signature) {
    const rawBody = (req as any).rawBody || JSON.stringify(req.body);
    const expectedSignature = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(signature))) {
      return res.status(400).json({ error: 'Invalid webhook signature.' });
    }
  }

  const payload = req.body;
  const event = payload.event;

  if (event === 'payment.captured' && payload.payload?.payment?.entity) {
    const paymentEntity = payload.payload.payment.entity;
    const orderId = paymentEntity.order_id;
    const paymentId = paymentEntity.id;

    // Verify and update idempotently
    verifyPaymentSignature({
      razorpay_order_id: orderId,
      razorpay_payment_id: paymentId,
      razorpay_signature: signature || 'webhook_verified',
    });
  }

  res.json({ status: 'ok' });
});

// Analytics tracking
apiRouter.post('/analytics/event', (req: Request, res: Response) => {
  const { event, path, metadata } = req.body;
  if (event) {
    db.logAnalytics(event, path || '/', metadata);
  }
  res.json({ success: true });
});

// -------------------------------------------------------------
// ADMIN AUTH ENDPOINTS
// -------------------------------------------------------------

apiRouter.post('/admin/login', (req: Request, res: Response) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const rateLimit = checkLoginRateLimit(ip);
  if (!rateLimit.allowed) {
    return res.status(429).json({
      error: `Too many failed login attempts. Account temporarily locked. Try again in ${rateLimit.remainingSeconds} seconds.`,
    });
  }

  const { password, email } = req.body;
  if (!password || !password.trim()) {
    return res.status(400).json({ error: 'Password is required.' });
  }

  const users = db.get('adminUsers');
  let user = email
    ? users.find(u => u.email.toLowerCase() === email.trim().toLowerCase() && u.isActive)
    : users.find(u => u.isActive && (u.role === 'SUPER_ADMIN' || u.role === 'ADMIN'));

  if (!user || !verifyPassword(password, user.passwordHash, user.salt)) {
    // If not matched, also check any other active admin user whose password matches
    const matchedUser = users.find(u => u.isActive && verifyPassword(password, u.passwordHash, u.salt));
    if (matchedUser) {
      user = matchedUser;
    } else {
      recordFailedLogin(ip);
      db.logAudit({ action: 'ADMIN_LOGIN_FAILED', entity: 'AdminUser', metadata: { ip, reason: 'Password mismatch or invalid credential' } });
      return res.status(401).json({ error: 'Invalid admin password.' });
    }
  }

  resetLoginAttempts(ip);
  const token = createSession(user);

  // Update lastLoginAt
  user.lastLoginAt = new Date().toISOString();
  db.set('adminUsers', users);

  db.logAudit({
    action: 'ADMIN_LOGIN_SUCCESS',
    entity: 'AdminUser',
    entityId: user.id,
    adminUserId: user.id,
    adminUserName: user.name,
    metadata: { ip },
  });

  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    },
  });
});

apiRouter.post('/admin/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    revokeSession(token);
  }
  res.json({ success: true });
});

apiRouter.get('/admin/me', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    lastLoginAt: user.lastLoginAt,
  });
});

apiRouter.post('/admin/change-password', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
  }

  const isCurrentValid = verifyPassword(currentPassword, user.passwordHash, user.salt);
  if (!isCurrentValid) {
    return res.status(400).json({ error: 'Current password does not match.' });
  }

  const { hash, salt } = hashPassword(newPassword);
  const users = db.get('adminUsers');
  const idx = users.findIndex(u => u.id === user.id);
  if (idx !== -1) {
    users[idx].passwordHash = hash;
    users[idx].salt = salt;
    users[idx].updatedAt = new Date().toISOString();
    db.set('adminUsers', users);
  }

  db.logAudit({
    action: 'ADMIN_PASSWORD_CHANGED',
    entity: 'AdminUser',
    entityId: user.id,
    adminUserId: user.id,
    adminUserName: user.name,
  });

  res.json({ success: true, message: 'Password updated successfully.' });
});

// -------------------------------------------------------------
// ADMIN MANAGEMENT ENDPOINTS
// -------------------------------------------------------------

apiRouter.get('/admin/overview', requireAuth, (req: Request, res: Response) => {
  const leads = db.get('leads');
  const bookings = db.get('bookings');
  const payments = db.get('payments');
  const customers = db.get('customers');
  const services = db.get('services');
  const auditLogs = db.get('auditLogs');
  const analyticsEvents = db.get('analyticsEvents');
  const settings = db.get('settings');

  res.json({
    metrics: {
      totalLeads: leads.length,
      newLeads: leads.filter(l => l.status === 'NEW').length,
      totalBookings: bookings.length,
      confirmedBookings: bookings.filter(b => b.status === 'CONFIRMED').length,
      totalPayments: payments.length,
      successfulPayments: payments.filter(p => p.status === 'SUCCESS').length,
      totalRevenueINR: payments.filter(p => p.status === 'SUCCESS').reduce((acc, p) => acc + p.amount, 0),
      totalCustomers: customers.length,
      totalServices: services.length,
      analyticsCount: analyticsEvents.length,
    },
    recentLeads: leads.slice(0, 5),
    recentBookings: bookings.slice(0, 5),
    recentPayments: payments.slice(0, 5),
    recentAuditLogs: auditLogs.slice(0, 8),
    settings,
  });
});

// CRM / Leads
apiRouter.get('/admin/leads', requireAuth, (req: Request, res: Response) => {
  const leads = db.get('leads');
  const { status, search } = req.query;

  let filtered = [...leads];
  if (status && status !== 'ALL') {
    filtered = filtered.filter(l => l.status === status);
  }
  if (search) {
    const q = (search as string).toLowerCase();
    filtered = filtered.filter(
      l => l.name.toLowerCase().includes(q) ||
           l.email.toLowerCase().includes(q) ||
           l.phone.includes(q) ||
           (l.companyName && l.companyName.toLowerCase().includes(q))
    );
  }

  res.json({ leads: filtered });
});

apiRouter.patch('/admin/leads/:id', requireAuth, async (req: Request, res: Response) => {
  const admin = (req as any).user;
  const leadId = req.params.id;
  const leads = db.get('leads');
  const idx = leads.findIndex(l => l.id === leadId);

  if (idx === -1) return res.status(404).json({ error: 'Lead not found.' });

  const allowedUpdates = ['status', 'notes', 'assignedTo', 'requirements', 'budget', 'timeline'];
  const lead = leads[idx];

  allowedUpdates.forEach(key => {
    if (req.body[key] !== undefined) {
      (lead as any)[key] = req.body[key];
    }
  });

  lead.updatedAt = new Date().toISOString();
  leads[idx] = lead;
  db.set('leads', leads);

  db.logAudit({
    action: 'LEAD_UPDATED',
    entity: 'Lead',
    entityId: leadId,
    adminUserId: admin.id,
    adminUserName: admin.name,
    metadata: req.body,
  });

  res.json({ success: true, lead });
});

apiRouter.post('/admin/leads/:id/sync-sheets', requireAuth, async (req: Request, res: Response) => {
  const leadId = req.params.id;
  const leads = db.get('leads');
  const lead = leads.find(l => l.id === leadId);
  if (!lead) return res.status(404).json({ error: 'Lead not found.' });

  const result = await syncLeadToGoogleSheets(lead);
  res.json(result);
});

// Bookings
apiRouter.get('/admin/bookings', requireAuth, (req: Request, res: Response) => {
  const bookings = db.get('bookings');
  res.json({ bookings });
});

apiRouter.patch('/admin/bookings/:id', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const bookingId = req.params.id;
  const bookings = db.get('bookings');
  const idx = bookings.findIndex(b => b.id === bookingId);
  if (idx === -1) return res.status(404).json({ error: 'Booking not found.' });

  const { status, paymentStatus, notes } = req.body;
  if (status) bookings[idx].status = status;
  if (paymentStatus) bookings[idx].paymentStatus = paymentStatus;
  if (notes !== undefined) bookings[idx].notes = notes;
  bookings[idx].updatedAt = new Date().toISOString();

  db.set('bookings', bookings);

  db.logAudit({
    action: 'BOOKING_UPDATED_BY_ADMIN',
    entity: 'Booking',
    entityId: bookingId,
    adminUserId: admin.id,
    adminUserName: admin.name,
    metadata: { status, paymentStatus },
  });

  res.json({ success: true, booking: bookings[idx] });
});

// Payments
apiRouter.get('/admin/payments', requireAuth, (req: Request, res: Response) => {
  const payments = db.get('payments');
  const { status } = req.query;
  let filtered = [...payments];
  if (status && status !== 'ALL') {
    filtered = filtered.filter(p => p.status === status);
  }
  res.json({ payments: filtered });
});

apiRouter.post('/admin/payments/:id/refund', requireAuth, (req: Request, res: Response) => {
  const paymentId = req.params.id;
  const { amount, reason } = req.body;
  const result = processRefund(paymentId, amount ? Number(amount) : undefined, reason);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }
  res.json(result);
});

// Customers
apiRouter.get('/admin/customers', requireAuth, (req: Request, res: Response) => {
  const customers = db.get('customers');
  res.json({ customers });
});

// Services & Prices
apiRouter.get('/admin/services', requireAuth, (req: Request, res: Response) => {
  const services = db.get('services');
  res.json({ services });
});

apiRouter.patch('/admin/services/:id', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const serviceId = req.params.id;
  const services = db.get('services');
  const idx = services.findIndex(s => s.id === serviceId);
  if (idx === -1) return res.status(404).json({ error: 'Service not found.' });

  const oldPrice = services[idx].price;
  const allowed = ['name', 'description', 'price', 'duration', 'isActive', 'sortOrder', 'features'];
  allowed.forEach(key => {
    if (req.body[key] !== undefined) {
      (services[idx] as any)[key] = req.body[key];
    }
  });
  services[idx].updatedAt = new Date().toISOString();
  db.set('services', services);

  db.logAudit({
    action: 'SERVICE_UPDATED',
    entity: 'Service',
    entityId: serviceId,
    adminUserId: admin.id,
    adminUserName: admin.name,
    metadata: {
      oldPrice,
      newPrice: services[idx].price,
      name: services[idx].name,
    },
  });

  res.json({ success: true, service: services[idx] });
});

// Team Members
apiRouter.get('/admin/team', requireAuth, (req: Request, res: Response) => {
  const teamMembers = db.get('teamMembers');
  res.json({ teamMembers });
});

apiRouter.patch('/admin/team/:id', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const id = req.params.id;
  const members = db.get('teamMembers');
  const idx = members.findIndex(m => m.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Team member not found.' });

  const allowed = ['name', 'role', 'bio', 'photo', 'skills', 'socialLinks', 'isActive', 'sortOrder'];
  allowed.forEach(key => {
    if (req.body[key] !== undefined) {
      (members[idx] as any)[key] = req.body[key];
    }
  });

  db.set('teamMembers', members);

  db.logAudit({
    action: 'TEAM_MEMBER_UPDATED',
    entity: 'TeamMember',
    entityId: id,
    adminUserId: admin.id,
    adminUserName: admin.name,
    metadata: req.body,
  });

  res.json({ success: true, member: members[idx] });
});

// FAQs
apiRouter.get('/admin/faqs', requireAuth, (req: Request, res: Response) => {
  const faqs = db.get('faqs');
  res.json({ faqs });
});

apiRouter.post('/admin/faqs', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const { question, answer, category, sortOrder } = req.body;
  if (!question || !answer) return res.status(400).json({ error: 'Question and answer required.' });

  const faqs = db.get('faqs');
  const newFaq = {
    id: `faq_${Date.now()}`,
    question,
    answer,
    category: category || 'General',
    sortOrder: sortOrder || faqs.length + 1,
    isPublished: true,
  };
  faqs.push(newFaq);
  db.set('faqs', faqs);

  db.logAudit({
    action: 'FAQ_CREATED',
    entity: 'FAQ',
    entityId: newFaq.id,
    adminUserId: admin.id,
    adminUserName: admin.name,
  });

  res.status(201).json({ success: true, faq: newFaq });
});

apiRouter.patch('/admin/faqs/:id', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const id = req.params.id;
  const faqs = db.get('faqs');
  const idx = faqs.findIndex(f => f.id === id);
  if (idx === -1) return res.status(404).json({ error: 'FAQ not found.' });

  Object.assign(faqs[idx], req.body);
  db.set('faqs', faqs);

  db.logAudit({
    action: 'FAQ_UPDATED',
    entity: 'FAQ',
    entityId: id,
    adminUserId: admin.id,
    adminUserName: admin.name,
  });

  res.json({ success: true, faq: faqs[idx] });
});

// Reviews (Real reviews only)
apiRouter.get('/admin/reviews', requireAuth, (req: Request, res: Response) => {
  const reviews = db.get('reviews');
  res.json({ reviews });
});

apiRouter.post('/admin/reviews', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const { source, reviewerName, rating, reviewText, reviewUrl, isVerified } = req.body;
  if (!reviewerName || !reviewText) return res.status(400).json({ error: 'Reviewer name and review text required.' });

  const reviews = db.get('reviews');
  const newReview = {
    id: `rev_${Date.now()}`,
    source: source || 'Direct Client Review',
    reviewerName,
    rating: Number(rating) || 5,
    reviewText,
    reviewUrl,
    isVerified: Boolean(isVerified),
    isPublished: true,
    createdAt: new Date().toISOString(),
  };

  reviews.push(newReview);
  db.set('reviews', reviews);

  db.logAudit({
    action: 'REVIEW_ADDED',
    entity: 'Review',
    entityId: newReview.id,
    adminUserId: admin.id,
    adminUserName: admin.name,
  });

  res.status(201).json({ success: true, review: newReview });
});

// Website Content
apiRouter.get('/admin/content', requireAuth, (req: Request, res: Response) => {
  const websiteContent = db.get('websiteContent');
  res.json({ websiteContent });
});

apiRouter.patch('/admin/content/:id', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const id = req.params.id;
  const content = db.get('websiteContent');
  const idx = content.findIndex(c => c.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Content item not found.' });

  if (req.body.value !== undefined) {
    content[idx].value = req.body.value;
  }
  content[idx].updatedBy = admin.name;
  content[idx].updatedAt = new Date().toISOString();
  db.set('websiteContent', content);

  db.logAudit({
    action: 'CONTENT_UPDATED',
    entity: 'WebsiteContent',
    entityId: id,
    adminUserId: admin.id,
    adminUserName: admin.name,
    metadata: { key: content[idx].key, section: content[idx].section },
  });

  res.json({ success: true, content: content[idx] });
});

// Settings
apiRouter.get('/admin/settings', requireAuth, (req: Request, res: Response) => {
  const settings = db.get('settings');
  res.json({ settings });
});

apiRouter.patch('/admin/settings', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const settings = db.get('settings');
  const allowed = [
    'phone', 'whatsapp', 'email', 'location', 'exactAddress', 'exactAddressVerified',
    'businessHours', 'razorpayKeyId', 'googleSheetsConnected', 'googleSheetId',
    'bookingAdvanceRequired', 'bookingAdvanceAmount'
  ];

  allowed.forEach(key => {
    if (req.body[key] !== undefined) {
      (settings as any)[key] = req.body[key];
    }
  });

  db.set('settings', settings);

  db.logAudit({
    action: 'SETTINGS_UPDATED',
    entity: 'SystemSettings',
    adminUserId: admin.id,
    adminUserName: admin.name,
    metadata: req.body,
  });

  res.json({ success: true, settings });
});

// Audit Logs
apiRouter.get('/admin/audit-logs', requireAuth, (req: Request, res: Response) => {
  const logs = db.get('auditLogs');
  res.json({ logs });
});

// Analytics
apiRouter.get('/admin/analytics', requireAuth, (req: Request, res: Response) => {
  const events = db.get('analyticsEvents');
  res.json({ events });
});

// Pre-launch Checklist
apiRouter.get('/admin/checklist', requireAuth, (req: Request, res: Response) => {
  const checklist = db.get('checklistState');
  res.json({ checklist });
});

apiRouter.patch('/admin/checklist', requireAuth, (req: Request, res: Response) => {
  const admin = (req as any).user;
  const current = db.get('checklistState');
  const { itemKey, status } = req.body;

  if (itemKey && status) {
    current[itemKey] = status;
    db.set('checklistState', current);

    db.logAudit({
      action: 'CHECKLIST_ITEM_UPDATED',
      entity: 'Checklist',
      adminUserId: admin.id,
      adminUserName: admin.name,
      metadata: { itemKey, status },
    });
  }

  res.json({ success: true, checklist: current });
});
