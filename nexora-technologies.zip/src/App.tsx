import React, { useState, useEffect } from 'react';
import { Lock } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { PricingCalculator } from './components/PricingCalculator';
import { TechnologySection } from './components/TechnologySection';
import { TeamSection } from './components/TeamSection';
import { ConsultationBooking } from './components/ConsultationBooking';
import { QuoteSection } from './components/QuoteSection';
import { FAQSection } from './components/FAQSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { LegalModals, PolicyType } from './components/LegalModals';
import { AdminPortal } from './components/AdminPortal';
import { fetchPublicInfo, PublicInfoResponse } from './lib/api';
import { Service } from './types';

export default function App() {
  const [data, setData] = useState<PublicInfoResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modal / Portal states
  const [adminPortalOpen, setAdminPortalOpen] = useState(false);
  const [activePolicy, setActivePolicy] = useState<PolicyType>(null);
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<string | undefined>();
  const [selectedServiceForQuote, setSelectedServiceForQuote] = useState<string | undefined>();

  useEffect(() => {
    fetchPublicInfo()
      .then(info => {
        setData(info);
      })
      .catch(err => {
        console.error('Failed to load initial business info:', err);
        setError('Network synchronization error. Please refresh the page.');
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const handleOpenBooking = (serviceId?: string) => {
    setSelectedServiceForBooking(serviceId);
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenQuote = (serviceId?: string) => {
    setSelectedServiceForQuote(serviceId);
    const el = document.getElementById('quote');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectService = (service: Service) => {
    handleOpenBooking(service.id);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#07090e] flex items-center justify-center text-slate-400">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
          <span className="text-xs font-mono tracking-wider text-slate-300">
            INITIALIZING NEXORA PLATFORM...
          </span>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-[#07090e] flex items-center justify-center p-4 text-center">
        <div className="max-w-md bg-[#0d121c] border border-red-500/20 rounded-xl p-8 space-y-4">
          <div className="text-base font-bold text-white font-display">System Connection Offline</div>
          <p className="text-xs text-slate-400">{error || 'Could not reach application server.'}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07090e] text-[#f1f3f9] flex flex-col antialiased selection:bg-blue-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        onOpenBooking={() => handleOpenBooking()}
        onOpenQuote={() => handleOpenQuote()}
        onOpenAdmin={() => setAdminPortalOpen(true)}
      />

      {/* Main Page Flow */}
      <main id="main-content" className="flex-1">
        {/* 1. Full-Screen Cinematic 3D Hero */}
        <Hero
          onOpenBooking={() => handleOpenBooking()}
          onOpenQuote={() => handleOpenQuote()}
          whatsappNumber={data.business.whatsapp}
        />

        {/* 2. Corporate About & Studio Architecture */}
        <AboutSection />

        {/* 3. Services with Exact Transparent Pricing */}
        <ServicesSection
          services={data.services}
          onSelectService={handleSelectService}
          onOpenQuote={handleOpenQuote}
        />

        {/* 4. Interactive Investment & Pricing Calculator */}
        <PricingCalculator
          services={data.services}
          onProceedToBooking={serviceId => handleOpenBooking(serviceId)}
        />

        {/* 5. 6-Phase Engineering Journey (IDEA to SUPPORT) */}
        <TechnologySection />

        {/* 6. Core Team Directory */}
        <TeamSection teamMembers={data.teamMembers} />

        {/* 7. Consultation Booking & Slot Lock Portal */}
        <ConsultationBooking
          services={data.services}
          initialServiceId={selectedServiceForBooking}
        />

        {/* 8. Structured Quote Request Pipeline */}
        <QuoteSection
          services={data.services}
          preselectedServiceId={selectedServiceForQuote}
        />

        {/* 9. Accessible FAQ Accordion */}
        <FAQSection faqs={data.faqs} />

        {/* 10. Direct Channels & 24 Hours Contact */}
        <ContactSection business={data.business} />
      </main>

      {/* Site Footer */}
      <Footer
        business={data.business}
        onOpenPolicy={type => setActivePolicy(type)}
        onOpenAdmin={() => setAdminPortalOpen(true)}
      />

      {/* Legal & Privacy Policy Modal */}
      <LegalModals
        activePolicy={activePolicy}
        onClose={() => setActivePolicy(null)}
      />

      {/* Floating Quick-Access Admin Dashboard Button */}
      <div className="fixed bottom-5 right-5 z-40">
        <button
          onClick={() => setAdminPortalOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-2.5 bg-[#0d121c]/90 hover:bg-[#121927] text-slate-200 hover:text-white border border-white/12 hover:border-blue-500/50 rounded-full shadow-2xl shadow-black/60 backdrop-blur-md transition-all duration-200 text-xs font-semibold focus-visible:outline-none"
          title="Open Admin Dashboard"
          aria-label="Open Admin Dashboard"
        >
          <div className="w-5 h-5 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <Lock className="w-3 h-3" aria-hidden="true" />
          </div>
          <span className="font-semibold tracking-wide">Admin Dashboard</span>
        </button>
      </div>

      {/* Private Admin Management Console */}
      <AdminPortal
        isOpen={adminPortalOpen}
        onClose={() => setAdminPortalOpen(false)}
      />
    </div>
  );
}
