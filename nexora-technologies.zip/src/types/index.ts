export interface Service {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  currency: string;
  pricingType: 'ONE_TIME' | 'MONTHLY' | 'CUSTOM';
  duration: string;
  isActive: boolean;
  sortOrder: number;
  features?: string[];
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio?: string;
  photo?: string;
  skills: string[];
  socialLinks: { [key: string]: string };
  sortOrder: number;
  isActive: boolean;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  sortOrder: number;
  isPublished: boolean;
}

export interface Review {
  id: string;
  source: string;
  reviewerName: string;
  rating: number;
  reviewText: string;
  reviewUrl?: string;
  isVerified: boolean;
  isPublished: boolean;
  createdAt: string;
}

export interface WebsiteContent {
  id: string;
  section: string;
  key: string;
  value: string;
  type: 'TEXT' | 'MARKDOWN' | 'JSON' | 'BOOLEAN';
  updatedAt: string;
}

export interface Lead {
  id: string;
  customerId?: string;
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  companyName?: string;
  serviceId: string;
  serviceName?: string;
  source: string;
  requirements: string;
  budget: string;
  timeline: string;
  status: 'NEW' | 'CONTACTED' | 'CONSULTATION' | 'PROPOSAL' | 'NEGOTIATION' | 'WON' | 'LOST';
  notes?: string;
  assignedTo?: string;
  syncedToSheets?: boolean;
  sheetsSyncedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerWhatsApp: string;
  customerEmail: string;
  serviceId: string;
  serviceName: string;
  bookingReference: string;
  date: string;
  startTime: string;
  endTime: string;
  timezone: string;
  status: 'PENDING' | 'CONFIRMED' | 'RESCHEDULED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW' | 'EXPIRED';
  requirements: string;
  notes?: string;
  paymentStatus: 'UNPAID' | 'HELD' | 'PAID' | 'REFUNDED' | 'RECONCILIATION_REQUIRED';
  paymentAmount: number;
  holdExpiresAt?: string;
  cancellationReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  bookingId?: string;
  customerId?: string;
  customerName?: string;
  serviceName?: string;
  gateway: 'RAZORPAY' | 'MANUAL';
  gatewayOrderId: string;
  gatewayPaymentId?: string;
  amount: number;
  currency: string;
  status: 'CREATED' | 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED' | 'CANCELLED';
  paymentMethod?: string;
  failureReason?: string;
  paidAt?: string;
  refundedAt?: string;
  refundAmount?: number;
  signatureVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  adminUserId?: string;
  adminUserName?: string;
  action: string;
  entity: string;
  entityId?: string;
  metadata?: any;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export interface PublicBusinessInfo {
  name: string;
  positioning: string;
  foundedYear: number;
  location: string;
  exactAddress: string | null;
  phone: string;
  whatsapp: string;
  email: string;
  businessHours: string;
  bookingAdvanceRequired: boolean;
  bookingAdvanceAmount: number;
}
