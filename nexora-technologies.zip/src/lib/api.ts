import { PublicBusinessInfo, Service, TeamMember, FAQ, Review, WebsiteContent, Booking, Lead, Payment, AuditLog } from '../types';

let adminAuthToken = localStorage.getItem('nexora_admin_token') || '';

export function setAdminToken(token: string) {
  adminAuthToken = token;
  if (token) {
    localStorage.setItem('nexora_admin_token', token);
  } else {
    localStorage.removeItem('nexora_admin_token');
  }
}

export function getAdminToken(): string {
  return adminAuthToken || localStorage.getItem('nexora_admin_token') || '';
}

export interface PublicInfoResponse {
  business: PublicBusinessInfo;
  services: Service[];
  teamMembers: TeamMember[];
  faqs: FAQ[];
  reviews: Review[];
  websiteContent: WebsiteContent[];
}

export async function fetchPublicInfo(): Promise<PublicInfoResponse> {
  const res = await fetch('/api/public/info');
  if (!res.ok) throw new Error('Failed to load platform information');
  return res.json();
}

export async function fetchAvailability(dateStr: string): Promise<{ date: string; slots: { time: string; available: boolean; reason?: string }[]; timezone: string }> {
  const res = await fetch(`/api/public/availability?date=${dateStr}`);
  if (!res.ok) throw new Error('Failed to retrieve slot availability');
  return res.json();
}

export async function submitBooking(data: {
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  serviceId: string;
  date: string;
  startTime: string;
  requirements: string;
  companyName?: string;
  advancePaymentRequired?: boolean;
}): Promise<{ success: boolean; booking: Booking; message: string }> {
  const res = await fetch('/api/public/book', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Failed to complete booking');
  return json;
}

export async function submitQuote(data: {
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  business?: string;
  serviceId: string;
  requirements: string;
  budget?: string;
  timeline?: string;
}): Promise<{ success: boolean; message: string; leadId: string; whatsappUrl: string; sheetsStatus?: string }> {
  const res = await fetch('/api/public/quote', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Failed to submit quote');
  return json;
}

export async function submitContact(data: {
  name: string;
  phone?: string;
  email: string;
  subject?: string;
  message: string;
}): Promise<{ success: boolean; message: string }> {
  const res = await fetch('/api/public/contact', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Failed to send message');
  return json;
}

export async function reschedulePublicBooking(data: {
  bookingReference: string;
  date: string;
  startTime: string;
  reason?: string;
}): Promise<{ success: boolean; message: string; booking: Booking }> {
  const res = await fetch('/api/public/reschedule', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Reschedule request failed');
  return json;
}

export async function cancelPublicBooking(data: {
  bookingReference: string;
  reason?: string;
}): Promise<{ success: boolean; message: string; booking: Booking }> {
  const res = await fetch('/api/public/cancel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Cancellation request failed');
  return json;
}

export async function trackAnalytics(event: string, path = window.location.pathname, metadata?: any) {
  try {
    await fetch('/api/analytics/event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event, path, metadata }),
    });
  } catch {
    // Non-blocking telemetry
  }
}

// Payment APIs
export async function createPaymentOrder(bookingId: string | undefined, amount: number) {
  const res = await fetch('/api/payments/create-order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ bookingId, amount }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Failed to initialize payment gateway order');
  return json;
}

export async function verifyPayment(data: {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
  bookingId?: string;
}) {
  const res = await fetch('/api/payments/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Payment signature verification failed');
  return json;
}

// Admin APIs
async function authFetch(url: string, options: RequestInit = {}) {
  const token = getAdminToken();
  const headers = new Headers(options.headers || {});
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (!headers.has('Content-Type') && options.method && options.method !== 'GET') {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(url, { ...options, headers });
  if (res.status === 401) {
    setAdminToken('');
    throw new Error('SESSION_EXPIRED');
  }
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Request failed');
  return json;
}

export async function adminLogin(password: string, email?: string) {
  const res = await fetch('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password, email }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Login failed');
  setAdminToken(json.token);
  return json;
}

export async function adminLogout() {
  try {
    await authFetch('/api/admin/logout', { method: 'POST' });
  } finally {
    setAdminToken('');
  }
}

export async function getAdminOverview() {
  return authFetch('/api/admin/overview');
}

export async function getAdminLeads(status?: string, search?: string) {
  const params = new URLSearchParams();
  if (status) params.set('status', status);
  if (search) params.set('search', search);
  return authFetch(`/api/admin/leads?${params.toString()}`);
}

export async function updateLead(id: string, updates: Partial<Lead>) {
  return authFetch(`/api/admin/leads/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
}

export async function syncLeadToSheets(id: string) {
  return authFetch(`/api/admin/leads/${id}/sync-sheets`, { method: 'POST' });
}

export async function getAdminBookings() {
  return authFetch('/api/admin/bookings');
}

export async function updateBooking(id: string, updates: Partial<Booking>) {
  return authFetch(`/api/admin/bookings/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
}

export async function getAdminPayments(status?: string) {
  const query = status && status !== 'ALL' ? `?status=${status}` : '';
  return authFetch(`/api/admin/payments${query}`);
}

export async function processPaymentRefund(id: string, amount?: number, reason?: string) {
  return authFetch(`/api/admin/payments/${id}/refund`, {
    method: 'POST',
    body: JSON.stringify({ amount, reason }),
  });
}

export async function getAdminCustomers() {
  return authFetch('/api/admin/customers');
}

export async function getAdminServices() {
  return authFetch('/api/admin/services');
}

export async function updateService(id: string, updates: Partial<Service>) {
  return authFetch(`/api/admin/services/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
}

export async function getAdminTeam() {
  return authFetch('/api/admin/team');
}

export async function updateTeamMember(id: string, updates: Partial<TeamMember>) {
  return authFetch(`/api/admin/team/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
}

export async function getAdminFAQs() {
  return authFetch('/api/admin/faqs');
}

export async function createFAQ(data: { question: string; answer: string; category?: string; sortOrder?: number }) {
  return authFetch('/api/admin/faqs', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updateFAQ(id: string, data: Partial<FAQ>) {
  return authFetch(`/api/admin/faqs/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  });
}

export async function getAdminReviews() {
  return authFetch('/api/admin/reviews');
}

export async function addReview(data: Partial<Review>) {
  return authFetch('/api/admin/reviews', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getAdminSettings() {
  return authFetch('/api/admin/settings');
}

export async function updateSettings(updates: any) {
  return authFetch('/api/admin/settings', {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
}

export async function getAdminAuditLogs() {
  return authFetch('/api/admin/audit-logs');
}

export async function getAdminChecklist() {
  return authFetch('/api/admin/checklist');
}

export async function updateChecklistItem(itemKey: string, status: string) {
  return authFetch('/api/admin/checklist', {
    method: 'PATCH',
    body: JSON.stringify({ itemKey, status }),
  });
}

export async function changeAdminPassword(currentPassword: string, newPassword: string) {
  return authFetch('/api/admin/change-password', {
    method: 'POST',
    body: JSON.stringify({ currentPassword, newPassword }),
  });
}
