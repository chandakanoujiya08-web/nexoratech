import React, { useState } from 'react';
import { Calculator, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import { Service } from '../types';

interface PricingCalculatorProps {
  services: Service[];
  onProceedToBooking: (serviceId: string) => void;
}

export const PricingCalculator: React.FC<PricingCalculatorProps> = ({
  services,
  onProceedToBooking,
}) => {
  // Service selections
  const [selectedCore, setSelectedCore] = useState<string>('srv_web_dev');
  const [includeWebInsurance, setIncludeWebInsurance] = useState<boolean>(true);
  const [includeAppInsurance, setIncludeAppInsurance] = useState<boolean>(false);
  const [includeMetaAds, setIncludeMetaAds] = useState<boolean>(false);

  const webDev = services.find(s => s.slug === 'web-development');
  const appDev = services.find(s => s.slug === 'app-development');
  const webIns = services.find(s => s.slug === 'web-insurance');
  const appIns = services.find(s => s.slug === 'app-insurance');
  const metaAds = services.find(s => s.slug === 'meta-ads');

  const webDevPrice = webDev ? webDev.price : 2999;
  const appDevPrice = appDev ? appDev.price : 7999;
  const webInsPrice = webIns ? webIns.price : 499;
  const appInsPrice = appIns ? appIns.price : 999;
  const metaAdsPrice = metaAds ? metaAds.price : 20000;

  // Calculate total
  let total = 0;
  if (selectedCore === 'srv_web_dev') total += webDevPrice;
  if (selectedCore === 'srv_app_dev') total += appDevPrice;
  if (selectedCore === 'both') total += (webDevPrice + appDevPrice);

  if (includeWebInsurance) total += webInsPrice;
  if (includeAppInsurance) total += appInsPrice;
  if (includeMetaAds) total += metaAdsPrice;

  const handleBooking = () => {
    const targetServiceId = selectedCore === 'srv_app_dev' ? (appDev?.id || 'srv_app_dev') : (webDev?.id || 'srv_web_dev');
    onProceedToBooking(targetServiceId);
  };

  return (
    <section
      id="pricing"
      className="py-24 border-t border-white/6 bg-[#080c14] relative"
      aria-label="Pricing Calculator"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <Calculator className="w-4 h-4" aria-hidden="true" />
            <span>Interactive Estimator</span>
            <span aria-hidden="true">·</span>
            <span>Zero Markup</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Calculate Your Exact Digital Investment.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            All prices reflect verified Nexora rates. Pick your core development target and optional security insurance for instant transparent totaling.
          </p>
        </div>

        {/* Calculator Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Options Matrix (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Step 1: Core Platform */}
            <div className="p-6 rounded-xl border border-white/8 bg-[#0d121c]">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
                Step 1: Select Primary Target
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedCore('srv_web_dev')}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    selectedCore === 'srv_web_dev'
                      ? 'border-blue-500 bg-blue-500/10 text-white'
                      : 'border-white/8 bg-white/2 text-slate-300 hover:border-white/16'
                  }`}
                >
                  <div className="text-sm font-semibold mb-1">Web Development</div>
                  <div className="text-lg font-bold font-mono tabular-nums text-white">
                    ₹{webDevPrice.toLocaleString('en-IN')}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Responsive Application</div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedCore('srv_app_dev')}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    selectedCore === 'srv_app_dev'
                      ? 'border-cyan-500 bg-cyan-500/10 text-white'
                      : 'border-white/8 bg-white/2 text-slate-300 hover:border-white/16'
                  }`}
                >
                  <div className="text-sm font-semibold mb-1">App Development</div>
                  <div className="text-lg font-bold font-mono tabular-nums text-white">
                    ₹{appDevPrice.toLocaleString('en-IN')}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">iOS &amp; Android Platform</div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedCore('both')}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    selectedCore === 'both'
                      ? 'border-purple-500 bg-purple-500/10 text-white'
                      : 'border-white/8 bg-white/2 text-slate-300 hover:border-white/16'
                  }`}
                >
                  <div className="text-sm font-semibold mb-1">Web + Mobile App</div>
                  <div className="text-lg font-bold font-mono tabular-nums text-white">
                    ₹{(webDevPrice + appDevPrice).toLocaleString('en-IN')}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Full Ecosystem</div>
                </button>
              </div>
            </div>

            {/* Step 2: Protection & Growth Add-ons */}
            <div className="p-6 rounded-xl border border-white/8 bg-[#0d121c] space-y-4">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Step 2: Add Verified Protection &amp; Growth Packages
              </div>

              {/* Web Insurance */}
              <label className="flex items-center justify-between p-3.5 rounded-lg border border-white/6 hover:bg-white/2 cursor-pointer transition-colors">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={includeWebInsurance}
                    onChange={e => setIncludeWebInsurance(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 text-blue-600 focus:ring-blue-500 bg-[#07090e]"
                  />
                  <div>
                    <div className="text-sm font-medium text-white">Web Insurance</div>
                    <div className="text-xs text-slate-400">Security hardening, uptime checks &amp; patches</div>
                  </div>
                </div>
                <div className="text-sm font-bold font-mono tabular-nums text-emerald-400">
                  +₹{webInsPrice.toLocaleString('en-IN')}
                </div>
              </label>

              {/* App Insurance */}
              <label className="flex items-center justify-between p-3.5 rounded-lg border border-white/6 hover:bg-white/2 cursor-pointer transition-colors">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={includeAppInsurance}
                    onChange={e => setIncludeAppInsurance(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 text-blue-600 focus:ring-blue-500 bg-[#07090e]"
                  />
                  <div>
                    <div className="text-sm font-medium text-white">App Insurance</div>
                    <div className="text-xs text-slate-400">OS compatibility updates &amp; crash audit</div>
                  </div>
                </div>
                <div className="text-sm font-bold font-mono tabular-nums text-amber-400">
                  +₹{appInsPrice.toLocaleString('en-IN')}
                </div>
              </label>

              {/* Meta Ads */}
              <label className="flex items-center justify-between p-3.5 rounded-lg border border-white/6 hover:bg-white/2 cursor-pointer transition-colors">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={includeMetaAds}
                    onChange={e => setIncludeMetaAds(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 text-blue-600 focus:ring-blue-500 bg-[#07090e]"
                  />
                  <div>
                    <div className="text-sm font-medium text-white">Meta Ads Campaign Architecture</div>
                    <div className="text-xs text-slate-400">Audience research, ad copy &amp; Pixel CAPI setup</div>
                  </div>
                </div>
                <div className="text-sm font-bold font-mono tabular-nums text-purple-400">
                  +₹{metaAdsPrice.toLocaleString('en-IN')}
                </div>
              </label>

            </div>

          </div>

          {/* Investment Summary Sticky Card (5 cols) */}
          <div className="lg:col-span-5 rounded-xl border border-blue-500/25 bg-[#0e1422] p-6 sm:p-8 shadow-xl shadow-blue-500/5">
            <div className="flex items-center justify-between gap-2 pb-5 border-b border-white/8">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Investment Breakdown
              </span>
              <span className="text-xs font-mono text-blue-400">INR (₹)</span>
            </div>

            <div className="py-6 space-y-3 text-sm">
              <div className="flex items-center justify-between text-slate-300">
                <span>
                  {selectedCore === 'srv_web_dev' && 'Web Development'}
                  {selectedCore === 'srv_app_dev' && 'App Development'}
                  {selectedCore === 'both' && 'Web + App Development'}
                </span>
                <span className="font-mono tabular-nums text-white">
                  ₹{selectedCore === 'srv_web_dev' ? webDevPrice.toLocaleString('en-IN') : selectedCore === 'srv_app_dev' ? appDevPrice.toLocaleString('en-IN') : (webDevPrice + appDevPrice).toLocaleString('en-IN')}
                </span>
              </div>

              {includeWebInsurance && (
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Web Insurance</span>
                  <span className="font-mono tabular-nums text-white">₹{webInsPrice.toLocaleString('en-IN')}</span>
                </div>
              )}

              {includeAppInsurance && (
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>App Insurance</span>
                  <span className="font-mono tabular-nums text-white">₹{appInsPrice.toLocaleString('en-IN')}</span>
                </div>
              )}

              {includeMetaAds && (
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Meta Ads</span>
                  <span className="font-mono tabular-nums text-white">₹{metaAdsPrice.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="pt-4 border-t border-white/8 flex items-baseline justify-between">
                <span className="text-base font-bold text-white">Total Investment</span>
                <span className="text-3xl font-extrabold text-blue-400 font-mono tabular-nums">
                  ₹{total.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-white/4 border border-white/6 text-xs text-slate-400 mb-6 leading-relaxed">
              Transparent fixed quotation. Invoices reflect the exact price applied at order creation.
            </div>

            <button
              onClick={handleBooking}
              className="w-full py-3.5 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <span>Book Consultation for this Plan</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
