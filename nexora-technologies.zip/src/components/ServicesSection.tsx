import React from 'react';
import { ArrowUpRight, Check, Globe, Smartphone, ShieldAlert, ShieldCheck, Megaphone } from 'lucide-react';
import { Service } from '../types';

interface ServicesSectionProps {
  services: Service[];
  onSelectService: (service: Service) => void;
  onOpenQuote: (serviceId?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  services,
  onSelectService,
  onOpenQuote,
}) => {
  const getIcon = (slug: string) => {
    switch (slug) {
      case 'web-development':
        return <Globe className="w-5 h-5 text-blue-400" aria-hidden="true" />;
      case 'app-development':
        return <Smartphone className="w-5 h-5 text-cyan-400" aria-hidden="true" />;
      case 'web-insurance':
        return <ShieldCheck className="w-5 h-5 text-emerald-400" aria-hidden="true" />;
      case 'app-insurance':
        return <ShieldAlert className="w-5 h-5 text-amber-400" aria-hidden="true" />;
      case 'meta-ads':
        return <Megaphone className="w-5 h-5 text-purple-400" aria-hidden="true" />;
      default:
        return <Globe className="w-5 h-5 text-blue-400" aria-hidden="true" />;
    }
  };

  return (
    <section
      id="services"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="Services and Solutions"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <span>Specialized Capabilities</span>
            <span aria-hidden="true">·</span>
            <span>Transparent Rates</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Engineered Web, App, and Digital Growth Solutions.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Every service is scoped with clear deliverables, honest timelines, and exact pricing. No surprise fees or ambiguous add-ons.
          </p>
        </div>

        {/* Services Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => {
            const isFeatured = service.slug === 'web-development' || service.slug === 'app-development';

            return (
              <div
                key={service.id}
                className={`rounded-xl border p-6 sm:p-7 flex flex-col justify-between transition-all duration-200 ${
                  isFeatured
                    ? 'border-blue-500/30 bg-[#0d1320] shadow-lg shadow-blue-500/5'
                    : 'border-white/8 bg-[#0a0e17] hover:border-white/16'
                }`}
              >
                <div>
                  {/* Service Top Row */}
                  <div className="flex items-center justify-between gap-4 mb-5">
                    <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                      {getIcon(service.slug)}
                    </div>
                    <span className="text-xs font-mono text-slate-400 tracking-wider">
                      0{idx + 1}
                    </span>
                  </div>

                  {/* Title & Price */}
                  <h3 className="text-xl font-bold text-white font-display mb-2">
                    {service.name}
                  </h3>

                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums">
                      ₹{service.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400">
                      {service.pricingType === 'ONE_TIME' ? 'one-time' : 'monthly'}
                    </span>
                  </div>

                  <p className="text-sm text-slate-300 leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Deliverables / Scope */}
                  {service.features && service.features.length > 0 && (
                    <div className="space-y-2.5 pt-4 border-t border-white/6 mb-6">
                      <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                        Deliverable Scope
                      </div>
                      {service.features.map((feature, fIdx) => (
                        <div key={fIdx} className="flex items-start gap-2.5 text-xs text-slate-300">
                          <Check className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" aria-hidden="true" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="pt-4 border-t border-white/6 flex items-center gap-3">
                  <button
                    onClick={() => onSelectService(service)}
                    className="flex-1 py-2.5 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-all flex items-center justify-center gap-1.5 whitespace-nowrap"
                  >
                    <span>Book Consultation</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-blue-200" aria-hidden="true" />
                  </button>
                  <button
                    onClick={() => onOpenQuote(service.id)}
                    className="py-2.5 px-3 text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all whitespace-nowrap"
                  >
                    Custom Quote
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
