import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Lock } from 'lucide-react';

interface NavbarProps {
  onOpenBooking: () => void;
  onOpenQuote: () => void;
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking, onOpenQuote, onOpenAdmin }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* Accessible skip-to-content link */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-blue-600 focus:text-white focus:rounded-md focus:shadow-lg focus:outline-none"
      >
        Skip to main content
      </a>

      {/* Top Bar adhering to strict one-row, three-zone contract */}
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#07090e]/85 backdrop-blur-md border-b border-white/8 shadow-lg shadow-black/20 py-3.5'
            : 'bg-transparent border-b border-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Zone 1: Single text element wordmark */}
          <a
            href="/"
            className="text-lg md:text-xl font-bold tracking-tight text-white font-display hover:text-blue-400 transition-colors shrink-0"
          >
            Nexora Technologies
          </a>

          {/* Zone 2: 4-6 clean text navigation links */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300"
          >
            <a
              href="#about"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              About
            </a>
            <a
              href="#services"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              Services
            </a>
            <a
              href="#pricing"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              Pricing
            </a>
            <a
              href="#technology"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              Technology
            </a>
            <a
              href="#team"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              Team
            </a>
            <a
              href="#faq"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              FAQ
            </a>
            <a
              href="#contact"
              className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-500 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: Primary actions + Admin Dashboard access */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenQuote}
              className="hidden xl:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-md transition-all whitespace-nowrap"
            >
              Get a Quote
            </button>

            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md shadow-sm shadow-blue-500/25 transition-all whitespace-nowrap"
            >
              <span>Book Consultation</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-blue-200" aria-hidden="true" />
            </button>

            {/* Direct Admin Dashboard Button */}
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-200 hover:text-white bg-white/6 hover:bg-white/12 border border-white/12 hover:border-blue-500/40 rounded-md transition-all whitespace-nowrap"
              title="Access Admin Dashboard"
              aria-label="Open Admin Dashboard"
            >
              <Lock className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
              <span className="hidden sm:inline">Admin Dashboard</span>
              <span className="sm:hidden">Admin</span>
            </button>

            {/* Mobile menu hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-300 hover:text-white rounded-md focus-visible:outline-none"
              aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div
            className="md:hidden bg-[#0a0e17] border-b border-white/10 px-4 pt-4 pb-6 space-y-3"
            aria-label="Mobile Menu"
          >
            <nav className="flex flex-col space-y-3 text-sm font-medium text-slate-300">
              <a
                href="#about"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                About Nexora
              </a>
              <a
                href="#services"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                Services & Capabilities
              </a>
              <a
                href="#pricing"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                Pricing Structure
              </a>
              <a
                href="#technology"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                Development Journey
              </a>
              <a
                href="#team"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                Team
              </a>
              <a
                href="#faq"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                FAQ
              </a>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-white py-1"
              >
                Contact & Location
              </a>
            </nav>

            <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenQuote();
                }}
                className="w-full py-2.5 text-xs font-semibold text-slate-200 bg-white/5 border border-white/10 rounded-md"
              >
                Get a Quote
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-2.5 text-xs font-semibold text-white bg-blue-600 rounded-md shadow-sm"
              >
                Book a Consultation
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="w-full py-2.5 text-xs font-semibold text-slate-200 hover:text-white bg-white/5 border border-white/10 rounded-md flex items-center justify-center gap-2"
              >
                <Lock className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
                <span>Admin Dashboard</span>
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
