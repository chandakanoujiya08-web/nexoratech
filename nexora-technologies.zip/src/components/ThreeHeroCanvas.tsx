import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

// Path to high-fidelity fallback image generated for hero
const FALLBACK_IMAGE = '/src/assets/images/hero_nexora_digital_core_1791026621557.jpg';

export const ThreeHeroCanvas: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [webglSupported, setWebglSupported] = useState<boolean>(true);
  const [reducedMotion, setReducedMotion] = useState<boolean>(false);

  useEffect(() => {
    // Check prefers-reduced-motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) {
      setReducedMotion(true);
      return;
    }

    const container = containerRef.current;
    if (!container) return;

    // Check WebGL availability
    try {
      const canvasTest = document.createElement('canvas');
      const gl = canvasTest.getContext('webgl') || canvasTest.getContext('experimental-webgl');
      if (!gl) {
        setWebglSupported(false);
        return;
      }
    } catch {
      setWebglSupported(false);
      return;
    }

    // 1. Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x07090e, 0.045);

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 8.5);

    // 3. Renderer setup
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
      renderer.setSize(container.clientWidth, container.clientHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.1;
      container.appendChild(renderer.domElement);
    } catch {
      setWebglSupported(false);
      return;
    }

    // 4. Lighting (Three-Point Studio Lighting)
    const ambientLight = new THREE.AmbientLight(0x0d1627, 2.5);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x3b82f6, 3.2); // Electric blue key
    keyLight.position.set(5, 4, 6);
    scene.add(keyLight);

    const fillLight = new THREE.PointLight(0x06b6d4, 2.8, 20); // Cyan fill
    fillLight.position.set(-6, -3, 3);
    scene.add(fillLight);

    const rimLight = new THREE.PointLight(0x8b5cf6, 3.5, 15); // Indigo rim
    rimLight.position.set(0, 5, -4);
    scene.add(rimLight);

    // 5. Digital Core & Connected Nodes Geometry
    const coreGroup = new THREE.Group();
    scene.add(coreGroup);

    // Inner Glowing Core Sphere
    const innerCoreGeo = new THREE.IcosahedronGeometry(1.35, 3);
    const innerCoreMat = new THREE.MeshStandardMaterial({
      color: 0x091428,
      emissive: 0x1d4ed8,
      emissiveIntensity: 0.8,
      roughness: 0.15,
      metalness: 0.9,
      wireframe: false,
    });
    const innerCore = new THREE.Mesh(innerCoreGeo, innerCoreMat);
    coreGroup.add(innerCore);

    // Outer Geodesic Lattice Wireframe
    const outerLatticeGeo = new THREE.IcosahedronGeometry(1.85, 2);
    const outerLatticeMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.6,
      wireframe: true,
      transparent: true,
      opacity: 0.38,
    });
    const outerLattice = new THREE.Mesh(outerLatticeGeo, outerLatticeMat);
    coreGroup.add(outerLattice);

    // Orbiting Geometric Rings (Abstract Interfaces)
    const ringGeo = new THREE.TorusGeometry(2.4, 0.015, 16, 100);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
    });
    const ring1 = new THREE.Mesh(ringGeo, ringMat);
    ring1.rotation.x = Math.PI / 3;
    coreGroup.add(ring1);

    const ring2 = new THREE.Mesh(ringGeo, ringMat.clone());
    ring2.rotation.y = Math.PI / 4;
    ring2.rotation.x = -Math.PI / 6;
    coreGroup.add(ring2);

    // Connected Neural / Digital Nodes
    const nodeCount = 38;
    const nodeGroup = new THREE.Group();
    coreGroup.add(nodeGroup);

    const nodeGeo = new THREE.SphereGeometry(0.045, 12, 12);
    const nodeMat = new THREE.MeshBasicMaterial({ color: 0x67e8f9 });
    const nodePositions: THREE.Vector3[] = [];

    for (let i = 0; i < nodeCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 2.1 + Math.random() * 0.9;
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta);
      const z = r * Math.cos(phi);

      const pos = new THREE.Vector3(x, y, z);
      nodePositions.push(pos);

      const nodeMesh = new THREE.Mesh(nodeGeo, nodeMat);
      nodeMesh.position.copy(pos);
      nodeGroup.add(nodeMesh);
    }

    // Connect some node pairs with luminous line filaments
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x2563eb,
      transparent: true,
      opacity: 0.32,
    });
    const lineGeo = new THREE.BufferGeometry();
    const linePoints: number[] = [];

    for (let i = 0; i < nodePositions.length; i++) {
      for (let j = i + 1; j < nodePositions.length; j++) {
        if (nodePositions[i].distanceTo(nodePositions[j]) < 1.45) {
          linePoints.push(
            nodePositions[i].x, nodePositions[i].y, nodePositions[i].z,
            nodePositions[j].x, nodePositions[j].y, nodePositions[j].z
          );
        }
      }
    }
    lineGeo.setAttribute('position', new THREE.Float32BufferAttribute(linePoints, 3));
    const filaments = new THREE.LineSegments(lineGeo, lineMat);
    coreGroup.add(filaments);

    // Floating Atmospheric Particle Field
    const particleCount = 240;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 14;
      particlePositions[i + 1] = (Math.random() - 0.5) * 10;
      particlePositions[i + 2] = (Math.random() - 0.5) * 10;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.035,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Mouse Tracking with Smooth Damping
    const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouse.targetX = x * 0.45;
      mouse.targetY = y * 0.35;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    // Scroll-based camera offset
    let scrollY = 0;
    const handleScroll = () => {
      scrollY = window.scrollY;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    // Window resize handler
    const handleResize = () => {
      if (!container || !renderer) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop with Smooth Interpolation
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth mouse damping
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Rotate digital core and structures
      coreGroup.rotation.y = elapsedTime * 0.12 + mouse.x;
      coreGroup.rotation.x = Math.sin(elapsedTime * 0.08) * 0.15 - mouse.y * 0.5;

      outerLattice.rotation.y = -elapsedTime * 0.09;
      outerLattice.rotation.z = Math.cos(elapsedTime * 0.06) * 0.12;

      ring1.rotation.z = elapsedTime * 0.15;
      ring2.rotation.z = -elapsedTime * 0.12;

      // Particle floating drift
      particles.rotation.y = elapsedTime * 0.02;

      // Scroll response
      const scrollOffset = scrollY * 0.0015;
      camera.position.y = mouse.y * 0.8 - scrollOffset;
      camera.position.x = mouse.x * 0.8;
      camera.lookAt(0, -scrollOffset * 0.5, 0);

      renderer.render(scene, camera);
    };

    animate();

    // WebGL context loss handling
    const canvasElement = renderer.domElement;
    const handleContextLost = (event: Event) => {
      event.preventDefault();
      setWebglSupported(false);
    };
    canvasElement.addEventListener('webglcontextlost', handleContextLost, false);

    // Cleanup
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
      canvasElement.removeEventListener('webglcontextlost', handleContextLost);
      cancelAnimationFrame(animationFrameId);

      // Dispose Three.js objects
      [innerCoreGeo, outerLatticeGeo, ringGeo, nodeGeo, lineGeo, particleGeo].forEach(g => g.dispose());
      [innerCoreMat, outerLatticeMat, ringMat, nodeMat, lineMat, particleMat].forEach(m => m.dispose());
      renderer.dispose();
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Graceful fallback for non-WebGL, low power, or reduced motion
  if (!webglSupported || reducedMotion) {
    return (
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <img
          src={FALLBACK_IMAGE}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-40 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07090e] via-transparent to-[#07090e]/80" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#07090e]/60 to-[#07090e]" />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none"
      aria-hidden="true"
    >
      {/* Cinematic contrast scrims */}
      <div className="absolute inset-0 bg-radial from-transparent via-[#07090e]/40 to-[#07090e] pointer-events-none" />
      <div className="absolute bottom-0 left-0 right-0 h-44 bg-gradient-to-t from-[#07090e] to-transparent pointer-events-none" />
    </div>
  );
};
