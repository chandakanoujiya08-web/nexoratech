import React from 'react';
import { ShieldCheck, Cpu, Target, Terminal, MapPin, Clock, Server } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section
      id="about"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="About Nexora Technologies"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <span>Corporate Profile</span>
            <span aria-hidden="true">·</span>
            <span>Founded 2026</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Engineering Purpose-Built Digital Systems from Vapi, Gujarat.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Nexora Technologies was established in 2026 to provide transparent, production-grade web and mobile software development. We believe digital products should be built on verifiable technical rigor, clean architectures, and honest partnerships.
          </p>
        </div>

        {/* Bento Grid: Story & Visuals */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Architectural Technical Blueprint Card (7 cols) - Clean Dark-Tech Canvas without external img */}
          <div className="lg:col-span-7 rounded-xl overflow-hidden border border-white/10 bg-[#0d111a] flex flex-col justify-between group">
            
            {/* Tech Blueprint & Systems Visualization */}
            <div className="relative aspect-16/9 w-full bg-[#080c14] border-b border-white/8 p-6 sm:p-8 flex flex-col justify-between overflow-hidden">
              
              {/* Subtle architectural background grid */}
              <div
                className="absolute inset-0 opacity-15 pointer-events-none"
                style={{
                  backgroundImage: `radial-gradient(rgba(59, 130, 246, 0.4) 1px, transparent 1px), linear-gradient(to right, rgba(255, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.03) 1px, transparent 1px)`,
                  backgroundSize: '24px 24px, 48px 48px, 48px 48px',
                }}
                aria-hidden="true"
              />

              {/* Top Blueprint Row */}
              <div className="relative z-10 flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-300">
                    Engineered in Vapi, Gujarat
                  </span>
                </div>
                <div className="text-[11px] font-mono text-slate-400">
                  EST. 2026 · ASIA/KOLKATA
                </div>
              </div>

              {/* Center Architecture Architecture Visualization */}
              <div className="relative z-10 my-4 grid grid-cols-3 gap-3 sm:gap-4">
                <div className="p-3.5 rounded-lg bg-white/3 border border-white/8 backdrop-blur-sm">
                  <div className="text-[10px] font-mono text-blue-400 mb-1 flex items-center gap-1.5">
                    <Server className="w-3 h-3" />
                    <span>PLATFORM</span>
                  </div>
                  <div className="text-xs font-bold text-white">Full-Stack Web &amp; App</div>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">React · Node · Native</div>
                </div>

                <div className="p-3.5 rounded-lg bg-white/3 border border-white/8 backdrop-blur-sm">
                  <div className="text-[10px] font-mono text-cyan-400 mb-1 flex items-center gap-1.5">
                    <Clock className="w-3 h-3" />
                    <span>SCHEDULE</span>
                  </div>
                  <div className="text-xs font-bold text-white">24 Hours Continuous</div>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">Rapid Deployment</div>
                </div>

                <div className="p-3.5 rounded-lg bg-white/3 border border-white/8 backdrop-blur-sm">
                  <div className="text-[10px] font-mono text-emerald-400 mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-3 h-3" />
                    <span>INTEGRITY</span>
                  </div>
                  <div className="text-xs font-bold text-white">Verifiable Pricing</div>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">Zero Simulated Data</div>
                </div>
              </div>

              {/* Bottom Blueprint Terminal Output */}
              <div className="relative z-10 flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-white/6">
                <span className="flex items-center gap-1 text-slate-300">
                  <Terminal className="w-3 h-3 text-blue-400" />
                  <span>nexora://core-systems</span>
                </span>
                <span className="text-blue-400">READY</span>
              </div>
            </div>

            {/* Content Details */}
            <div className="p-6 sm:p-8">
              <div className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
                Operational Base · Vapi, Gujarat
              </div>
              <h3 className="text-xl font-bold text-white font-display mb-2">
                Locally Rooted. Globally Capable.
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Operating 24 hours to serve domestic enterprises across Gujarat, founders throughout India, and international clientele requiring modern, robust digital applications.
              </p>
            </div>
          </div>

          {/* Core Values & Commitments (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-4">
            
            <div className="p-6 rounded-xl border border-white/8 bg-[#0d111a]/80">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 mb-4">
                <Target className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Clear Positioning</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                "Innovating Web and App Solutions for Tomorrow." We turn complex business requirements into clean, scalable digital software.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-white/8 bg-[#0d111a]/80">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-4">
                <ShieldCheck className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Integrity First (No Simulated Proof)</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                We never fabricate vanity statistics, fake customer logos, or simulated reviews. Every metric, price, and testimonial in our system is verifiable.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-white/8 bg-[#0d111a]/80">
              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-4">
                <Cpu className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Who We Build For</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Individuals, startups, established enterprises, and organizations seeking trustworthy technology execution without marketing fluff.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
