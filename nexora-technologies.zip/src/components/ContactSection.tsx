import React, { useState } from 'react';
import { Phone, Mail, Clock, MapPin, MessageSquare, Send, CheckCircle2, AlertCircle, ArrowUpRight } from 'lucide-react';
import { submitContact, trackAnalytics } from '../lib/api';

interface ContactSectionProps {
  business: {
    name: string;
    phone: string;
    whatsapp: string;
    email: string;
    location: string;
    exactAddress?: string | null;
    businessHours: string;
  };
}

export const ContactSection: React.FC<ContactSectionProps> = ({ business }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('General Consultation');
  const [message, setMessage] = useState('');

  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const cleanWhatsApp = business.whatsapp.replace(/[^\d]/g, '');
  const cleanPhone = business.phone.replace(/[^\d]/g, '');
  const prefilledWhatsAppUrl = `https://wa.me/${cleanWhatsApp}?text=${encodeURIComponent(
    'Hello Nexora Technologies, I would like to discuss a website/app project.'
  )}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      setErrorMsg('Name, email, and message are mandatory.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await submitContact({
        name,
        phone,
        email,
        subject,
        message,
      });

      setSuccessMsg(res.message);
      setName('');
      setPhone('');
      setEmail('');
      setMessage('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to dispatch message. Please try WhatsApp directly.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      id="contact"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="Contact Information and Direct Inquiries"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <span>Direct Channels</span>
            <span aria-hidden="true">·</span>
            <span>24 Hours Continuous</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Connect with Nexora Technologies.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Reach our engineering leadership in Vapi, Gujarat anytime. We provide around-the-clock availability for direct consultations and rapid project kickoffs.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Channel Cards (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* WhatsApp Card */}
            <div className="p-6 rounded-xl border border-emerald-500/20 bg-emerald-950/15">
              <div className="flex items-center justify-between gap-4 mb-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400">
                  <MessageSquare className="w-5 h-5" aria-hidden="true" />
                </div>
                <span className="text-xs font-mono text-emerald-400">Instant Chat</span>
              </div>
              <h3 className="text-base font-semibold text-white mb-1">WhatsApp Business</h3>
              <p className="text-sm font-mono text-emerald-300 mb-4">{business.whatsapp}</p>
              <a
                href={prefilledWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackAnalytics('contact_whatsapp_click')}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-all flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <span>CHAT WITH NEXORA</span>
                <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
              </a>
            </div>

            {/* Direct Phone */}
            <div className="p-6 rounded-xl border border-white/8 bg-[#0a0e17]">
              <div className="flex items-center gap-3.5 mb-2">
                <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                  <Phone className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Telephone Line</div>
                  <a
                    href={`tel:${cleanPhone}`}
                    onClick={() => trackAnalytics('contact_phone_click')}
                    className="text-sm font-mono font-semibold text-white hover:text-blue-400 transition-colors"
                  >
                    {business.phone}
                  </a>
                </div>
              </div>
            </div>

            {/* Direct Email */}
            <div className="p-6 rounded-xl border border-white/8 bg-[#0a0e17]">
              <div className="flex items-center gap-3.5 mb-2">
                <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <Mail className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Official Email</div>
                  <a
                    href={`mailto:${business.email}`}
                    onClick={() => trackAnalytics('contact_email_click')}
                    className="text-sm font-semibold text-white hover:text-cyan-400 transition-colors break-all"
                  >
                    {business.email}
                  </a>
                </div>
              </div>
            </div>

            {/* Operational Location & Hours */}
            <div className="p-6 rounded-xl border border-white/8 bg-[#0a0e17] space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 shrink-0">
                  <MapPin className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Registered Operational Base</div>
                  <div className="text-sm font-medium text-white">
                    {business.exactAddress || business.location}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">Gujarat, India</div>
                </div>
              </div>

              <div className="flex items-start gap-3.5 pt-3 border-t border-white/6">
                <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 shrink-0">
                  <Clock className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Business Hours</div>
                  <div className="text-sm font-medium text-white">{business.businessHours}</div>
                  <div className="text-xs text-slate-400 mt-0.5">Continuous engineering availability</div>
                </div>
              </div>
            </div>

          </div>

          {/* Direct Inquiry Form (7 cols) */}
          <div className="lg:col-span-7 bg-[#0d121c] border border-white/8 rounded-xl p-6 sm:p-8">
            <h3 className="text-lg font-bold text-white font-display mb-1">
              Direct Message Dispatch
            </h3>
            <p className="text-xs text-slate-400 mb-6">
              Send a note directly to our lead intake pipeline. We review incoming queries throughout our 24-hour operational cycle.
            </p>

            {successMsg ? (
              <div className="py-8 text-center space-y-4">
                <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" aria-hidden="true" />
                </div>
                <h4 className="text-lg font-bold text-white font-display">Message Dispatched</h4>
                <p className="text-sm text-slate-300 max-w-sm mx-auto">{successMsg}</p>
                <button
                  type="button"
                  onClick={() => setSuccessMsg(null)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-all"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMsg && (
                  <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" aria-hidden="true" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="e.g. Ananya Mehta"
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="+91 99248 XXXXX"
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="ananya@company.com"
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={e => setSubject(e.target.value)}
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Your Message *
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    placeholder="Provide details about your project or inquiry..."
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  {loading ? (
                    <span>Transmitting...</span>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Send Direct Message</span>
                    </>
                  )}
                </button>
              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
