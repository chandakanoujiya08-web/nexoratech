import React from 'react';
import { User } from 'lucide-react';
import { TeamMember } from '../types';

interface TeamSectionProps {
  teamMembers: TeamMember[];
}

export const TeamSection: React.FC<TeamSectionProps> = ({ teamMembers }) => {
  return (
    <section
      id="team"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="Core Engineering & Leadership Team"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <span>Leadership &amp; Execution</span>
            <span aria-hidden="true">·</span>
            <span>Core Team</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            The Minds Behind Nexora Technologies.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Our specialized multi-disciplinary team oversees every aspect of your project—from strategic planning and high-fidelity design to full-stack code and growth execution.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {teamMembers.map(member => (
            <div
              key={member.id}
              className="p-6 rounded-xl border border-white/8 bg-[#0a0e17] hover:border-white/16 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                {/* Avatar Placeholder / Photo */}
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600/20 to-cyan-600/10 border border-white/12 flex items-center justify-center text-blue-400 mb-4 overflow-hidden">
                  {member.photo ? (
                    <img
                      src={member.photo}
                      alt={member.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="w-8 h-8 opacity-80" aria-hidden="true" />
                  )}
                </div>

                {/* Name & Role */}
                <h3 className="text-lg font-bold text-white font-display">
                  {member.name}
                </h3>
                <div className="text-xs font-medium text-blue-400 mb-3">
                  {member.role}
                </div>

                {/* Bio */}
                {member.bio && (
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    {member.bio}
                  </p>
                )}
              </div>

              {/* Skills */}
              {member.skills && member.skills.length > 0 && (
                <div className="pt-3 border-t border-white/6 flex flex-wrap gap-1.5">
                  {member.skills.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-[11px] font-mono text-slate-400"
                    >
                      {skill}{sIdx < member.skills.length - 1 ? ' ·' : ''}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
