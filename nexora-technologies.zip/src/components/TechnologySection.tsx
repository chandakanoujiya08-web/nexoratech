import React from 'react';
import { Lightbulb, Palette, Code, CheckCircle, Rocket, LifeBuoy } from 'lucide-react';

const TECH_IMAGE = '/src/assets/images/tech_architecture_flow_1791026633993.jpg';

const STAGES = [
  {
    step: '01',
    name: 'Idea & Requirements',
    icon: Lightbulb,
    description: 'Deconstructing core business objectives, identifying user personas, and specifying exact functional deliverables without speculation.',
  },
  {
    step: '02',
    name: 'System Design & UX',
    icon: Palette,
    description: 'Structuring intuitive interfaces, accessible design tokens (WCAG 2.2 AA), and resilient relational data models.',
  },
  {
    step: '03',
    name: 'Full-Stack Development',
    icon: Code,
    description: 'Writing typed, maintainable TypeScript code with modern frameworks, strict security headers, and fast query execution.',
  },
  {
    step: '04',
    name: 'Rigorous Testing',
    icon: CheckCircle,
    description: 'Validating end-to-end flows, cross-device responsiveness, payment idempotency, and double-booking concurrency constraints.',
  },
  {
    step: '05',
    name: 'Production Launch',
    icon: Rocket,
    description: 'Configuring domain routing, SSL certification, server deployment, and technical SEO metadata with zero downtime.',
  },
  {
    step: '06',
    name: 'Dedicated Support',
    icon: LifeBuoy,
    description: 'Ongoing post-launch stability, dependency updates, and optional Web & App Insurance packages.',
  },
];

export const TechnologySection: React.FC = () => {
  return (
    <section
      id="technology"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="Development Journey and Technology"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <span>Engineering Discipline</span>
            <span aria-hidden="true">·</span>
            <span>6-Phase Lifecycle</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            A Systematic Development Journey.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            We follow an engineering pipeline that progresses sequentially from conceptualization to sustained operational support. No unverified certifications or marketing exaggeration.
          </p>
        </div>

        {/* Visual Architecture Banner */}
        <div className="rounded-xl overflow-hidden border border-white/10 bg-[#0d121c] mb-12 relative">
          <div className="aspect-21/9 w-full relative overflow-hidden max-h-72">
            <img
              src={TECH_IMAGE}
              alt="Nexora engineering architecture visualization and interface structure"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center opacity-65"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0d121c] via-[#0d121c]/40 to-transparent" />
          </div>

          <div className="p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/6">
            <div>
              <div className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-1">
                Engineering Standard
              </div>
              <div className="text-base font-bold text-white">
                IDEA → DESIGN → DEVELOPMENT → TESTING → LAUNCH → SUPPORT
              </div>
            </div>
            <div className="text-xs text-slate-400 max-w-md">
              Every phase is milestone-driven, testable, and reviewed directly with our clients before proceeding to the next stage.
            </div>
          </div>
        </div>

        {/* 6 Stages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {STAGES.map(stage => {
            const Icon = stage.icon;
            return (
              <div
                key={stage.step}
                className="p-6 rounded-xl border border-white/8 bg-[#0a0e17] hover:border-white/16 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-4 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </div>
                    <span className="text-xs font-mono text-slate-500">
                      Phase {stage.step}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white font-display mb-2">
                    {stage.name}
                  </h3>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    {stage.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
