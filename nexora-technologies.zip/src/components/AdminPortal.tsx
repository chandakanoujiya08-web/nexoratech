import React, { useState, useEffect } from 'react';
import {
  Lock, LogOut, CheckCircle2, AlertCircle, RefreshCw, Search,
  Users, Calendar, CreditCard, Layers, HelpCircle, FileText,
  Settings as SettingsIcon, ShieldCheck, CheckSquare, ChevronRight,
  TrendingUp, Clock, DollarSign, Database, Send, ExternalLink, X,
  Eye, EyeOff
} from 'lucide-react';
import {
  adminLogin, adminLogout, getAdminOverview, getAdminLeads, updateLead,
  syncLeadToSheets, getAdminBookings, updateBooking, getAdminPayments,
  processPaymentRefund, getAdminServices, updateService, getAdminTeam,
  updateTeamMember, getAdminFAQs, createFAQ, updateFAQ, getAdminReviews,
  addReview, getAdminSettings, updateSettings, getAdminAuditLogs,
  getAdminChecklist, updateChecklistItem, changeAdminPassword, getAdminToken
} from '../lib/api';
import { Lead, Booking, Payment, Service, TeamMember, FAQ, Review, AuditLog } from '../types';

interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AdminTab =
  | 'OVERVIEW'
  | 'LEADS'
  | 'BOOKINGS'
  | 'PAYMENTS'
  | 'SERVICES'
  | 'TEAM'
  | 'REVIEWS'
  | 'FAQS'
  | 'CHECKLIST'
  | 'SETTINGS'
  | 'AUDIT_LOGS';

export const AdminPortal: React.FC<AdminPortalProps> = ({ isOpen, onClose }) => {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(Boolean(getAdminToken()));
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<AdminTab>('OVERVIEW');

  // Data states
  const [overview, setOverview] = useState<any>(null);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [checklist, setChecklist] = useState<{ [key: string]: string }>({});
  const [settings, setSettings] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Filter & Search states
  const [leadStatusFilter, setLeadStatusFilter] = useState('ALL');
  const [leadSearch, setLeadSearch] = useState('');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('ALL');

  // Loading & notification states
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Password change modal
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');

  // New FAQ / Review modal states
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');
  const [newReviewAuthor, setNewReviewAuthor] = useState('');
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState('5');

  // Load active tab data
  const loadData = async () => {
    if (!isAuthenticated) return;
    setLoading(true);
    try {
      if (activeTab === 'OVERVIEW') {
        const data = await getAdminOverview();
        setOverview(data);
      } else if (activeTab === 'LEADS') {
        const data = await getAdminLeads(leadStatusFilter, leadSearch);
        setLeads(data.leads);
      } else if (activeTab === 'BOOKINGS') {
        const data = await getAdminBookings();
        setBookings(data.bookings);
      } else if (activeTab === 'PAYMENTS') {
        const data = await getAdminPayments(paymentStatusFilter);
        setPayments(data.payments);
      } else if (activeTab === 'SERVICES') {
        const data = await getAdminServices();
        setServices(data.services);
      } else if (activeTab === 'TEAM') {
        const data = await getAdminTeam();
        setTeamMembers(data.teamMembers);
      } else if (activeTab === 'REVIEWS') {
        const data = await getAdminReviews();
        setReviews(data.reviews);
      } else if (activeTab === 'FAQS') {
        const data = await getAdminFAQs();
        setFaqs(data.faqs);
      } else if (activeTab === 'CHECKLIST') {
        const data = await getAdminChecklist();
        setChecklist(data.checklist);
      } else if (activeTab === 'SETTINGS') {
        const data = await getAdminSettings();
        setSettings(data.settings);
      } else if (activeTab === 'AUDIT_LOGS') {
        const data = await getAdminAuditLogs();
        setAuditLogs(data.logs);
      }
    } catch (err: any) {
      if (err.message === 'SESSION_EXPIRED') {
        setIsAuthenticated(false);
      } else {
        setNotification({ type: 'error', message: err.message || 'Failed to fetch data' });
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      loadData();
    }
  }, [isOpen, isAuthenticated, activeTab, leadStatusFilter, paymentStatusFilter]);

  if (!isOpen) return null;

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginPassword.trim()) {
      setLoginError('Please enter the admin password.');
      return;
    }
    setLoginLoading(true);
    setLoginError(null);
    try {
      await adminLogin(loginPassword);
      setIsAuthenticated(true);
      setActiveTab('OVERVIEW');
    } catch (err: any) {
      setLoginError(err.message || 'Invalid admin password.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    await adminLogout();
    setIsAuthenticated(false);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await changeAdminPassword(currentPass, newPass);
      setNotification({ type: 'success', message: 'Admin password updated successfully.' });
      setShowPasswordModal(false);
      setCurrentPass('');
      setNewPass('');
    } catch (err: any) {
      setNotification({ type: 'error', message: err.message || 'Failed to change password.' });
    }
  };

  // Check if checklist passes all mandatory items
  const allMandatoryPassed = Object.values(checklist).length > 0 && Object.values(checklist).every(status => status === 'COMPLETED');

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      <div className="bg-[#0b0f17] border border-white/12 rounded-2xl w-full max-w-7xl h-[94vh] flex flex-col shadow-2xl overflow-hidden text-slate-200">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/8 bg-[#070a10]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white font-display">
                Nexora Technologies · Command &amp; Control
              </div>
              <div className="text-[11px] text-slate-400">
                Secure Business Architecture &amp; Data Administration
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && (
              <>
                <button
                  onClick={() => setShowPasswordModal(true)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-md transition-colors"
                >
                  Change Password
                </button>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 text-xs text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-md transition-colors flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
              aria-label="Close Admin Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notification Banner */}
        {notification && (
          <div
            className={`px-6 py-2.5 text-xs flex items-center justify-between ${
              notification.type === 'success'
                ? 'bg-emerald-950/60 text-emerald-300 border-b border-emerald-500/20'
                : 'bg-red-950/60 text-red-300 border-b border-red-500/20'
            }`}
          >
            <div className="flex items-center gap-2">
              {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-red-400" />}
              <span>{notification.message}</span>
            </div>
            <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-white">✕</button>
          </div>
        )}

        {/* LOGIN SCREEN IF UNAUTHENTICATED */}
        {!isAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-6 bg-[#070a10]">
            <div className="max-w-md w-full bg-[#0e131e] border border-white/10 rounded-xl p-8 shadow-xl">
              <div className="text-center mb-6">
                <div className="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white font-display">Admin Dashboard Access</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Enter master password to unlock administration portal.
                </p>
              </div>

              {loginError && (
                <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Admin Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      autoFocus
                      value={loginPassword}
                      onChange={e => setLoginPassword(e.target.value)}
                      placeholder="Enter admin password..."
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg pl-3.5 pr-10 py-2.5 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loginLoading || !loginPassword}
                  className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg shadow-sm transition-all"
                >
                  {loginLoading ? 'Authenticating...' : 'Unlock Admin Dashboard'}
                </button>
              </form>

              <div className="mt-6 pt-4 border-t border-white/6 text-[11px] text-slate-400 leading-relaxed text-center">
                Master password: <code className="text-blue-300 font-mono font-semibold">NexoraAdmin2026!</code>
              </div>
            </div>
          </div>
        ) : (
          /* AUTHENTICATED WORKSPACE */
          <div className="flex-1 flex overflow-hidden">
            
            {/* Sidebar Navigation */}
            <div className="w-56 bg-[#070a10] border-r border-white/8 p-3 flex flex-col justify-between shrink-0 overflow-y-auto">
              <nav className="space-y-1 text-xs">
                <button
                  onClick={() => setActiveTab('OVERVIEW')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'OVERVIEW' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Overview</span>
                </button>

                <button
                  onClick={() => setActiveTab('LEADS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'LEADS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Leads &amp; CRM</span>
                </button>

                <button
                  onClick={() => setActiveTab('BOOKINGS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'BOOKINGS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  <span>Bookings</span>
                </button>

                <button
                  onClick={() => setActiveTab('PAYMENTS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'PAYMENTS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Payments</span>
                </button>

                <button
                  onClick={() => setActiveTab('SERVICES')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'SERVICES' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  <span>Services &amp; Pricing</span>
                </button>

                <button
                  onClick={() => setActiveTab('TEAM')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'TEAM' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Team Members</span>
                </button>

                <button
                  onClick={() => setActiveTab('REVIEWS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'REVIEWS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Client Reviews</span>
                </button>

                <button
                  onClick={() => setActiveTab('FAQS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'FAQS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <HelpCircle className="w-4 h-4" />
                  <span>FAQ Editor</span>
                </button>

                <button
                  onClick={() => setActiveTab('CHECKLIST')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'CHECKLIST' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <CheckSquare className="w-4 h-4" />
                  <span>Pre-Launch Checklist</span>
                </button>

                <button
                  onClick={() => setActiveTab('SETTINGS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'SETTINGS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <SettingsIcon className="w-4 h-4" />
                  <span>Settings &amp; Keys</span>
                </button>

                <button
                  onClick={() => setActiveTab('AUDIT_LOGS')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors text-left ${
                    activeTab === 'AUDIT_LOGS' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  <span>Audit Logs</span>
                </button>
              </nav>

              <div className="p-3 bg-white/2 border border-white/6 rounded-lg text-[11px] text-slate-400 space-y-1">
                <div>Backend: <span className="text-emerald-400">Active</span></div>
                <div>Timezone: <span className="text-white">Asia/Kolkata</span></div>
              </div>
            </div>

            {/* Main Content Workspace */}
            <div className="flex-1 bg-[#090d15] overflow-y-auto p-6 sm:p-8">
              
              {/* TAB: OVERVIEW */}
              {activeTab === 'OVERVIEW' && overview && (
                <div className="space-y-8">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">Operational Overview</h3>
                    <p className="text-xs text-slate-400">Verifiable production counters. Zero fabricated figures.</p>
                  </div>

                  {/* Counter Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e]">
                      <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Total Leads</div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-white">
                        {overview.metrics.totalLeads}
                      </div>
                      <div className="text-[11px] text-blue-400 mt-1">{overview.metrics.newLeads} pending review</div>
                    </div>

                    <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e]">
                      <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Bookings</div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-white">
                        {overview.metrics.totalBookings}
                      </div>
                      <div className="text-[11px] text-emerald-400 mt-1">{overview.metrics.confirmedBookings} confirmed</div>
                    </div>

                    <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e]">
                      <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Payments Processed</div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-white">
                        {overview.metrics.successfulPayments}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">{overview.metrics.totalPayments} total gateway attempts</div>
                    </div>

                    <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e]">
                      <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Captured Revenue</div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400">
                        ₹{overview.metrics.totalRevenueINR.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">Verified bank receipts</div>
                    </div>
                  </div>

                  {/* Recent Activity Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Recent Inquiries */}
                    <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e]">
                      <div className="flex items-center justify-between pb-3 border-b border-white/6 mb-4">
                        <span className="text-xs font-semibold text-white uppercase tracking-wider">Recent Leads</span>
                        <button onClick={() => setActiveTab('LEADS')} className="text-xs text-blue-400 hover:text-blue-300">View all</button>
                      </div>

                      {overview.recentLeads.length === 0 ? (
                        <div className="py-8 text-center text-xs text-slate-500 font-mono">NO LEADS YET</div>
                      ) : (
                        <div className="space-y-3">
                          {overview.recentLeads.map((l: Lead) => (
                            <div key={l.id} className="p-3 rounded-lg bg-white/2 border border-white/4 text-xs flex justify-between items-center">
                              <div>
                                <div className="font-semibold text-white">{l.name}</div>
                                <div className="text-slate-400">{l.serviceName} · {l.phone}</div>
                              </div>
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/20">{l.status}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Recent Bookings */}
                    <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e]">
                      <div className="flex items-center justify-between pb-3 border-b border-white/6 mb-4">
                        <span className="text-xs font-semibold text-white uppercase tracking-wider">Recent Consultations</span>
                        <button onClick={() => setActiveTab('BOOKINGS')} className="text-xs text-blue-400 hover:text-blue-300">View all</button>
                      </div>

                      {overview.recentBookings.length === 0 ? (
                        <div className="py-8 text-center text-xs text-slate-500 font-mono">NO BOOKINGS YET</div>
                      ) : (
                        <div className="space-y-3">
                          {overview.recentBookings.map((b: Booking) => (
                            <div key={b.id} className="p-3 rounded-lg bg-white/2 border border-white/4 text-xs flex justify-between items-center">
                              <div>
                                <div className="font-semibold text-white">{b.customerName}</div>
                                <div className="text-slate-400">{b.date} at {b.startTime} ({b.serviceName})</div>
                              </div>
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">{b.status}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: LEADS / CRM */}
              {activeTab === 'LEADS' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-xl font-bold text-white font-display">Lead Management CRM</h3>
                      <p className="text-xs text-slate-400">Track client inquiries, quote requests, and Google Sheets sync status.</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <select
                        value={leadStatusFilter}
                        onChange={e => setLeadStatusFilter(e.target.value)}
                        className="bg-[#0e131e] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                      >
                        <option value="ALL">All Statuses</option>
                        <option value="NEW">NEW</option>
                        <option value="CONTACTED">CONTACTED</option>
                        <option value="CONSULTATION">CONSULTATION</option>
                        <option value="PROPOSAL">PROPOSAL</option>
                        <option value="WON">WON</option>
                        <option value="LOST">LOST</option>
                      </select>

                      <button
                        onClick={loadData}
                        className="p-2 text-slate-400 hover:text-white bg-[#0e131e] border border-white/10 rounded-lg"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {leads.length === 0 ? (
                    <div className="py-16 text-center text-xs text-slate-500 font-mono bg-[#0e131e] border border-white/8 rounded-xl">
                      NO LEADS YET
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {leads.map(lead => (
                        <div key={lead.id} className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div>
                              <span className="text-sm font-bold text-white">{lead.name}</span>
                              {lead.companyName && <span className="text-xs text-slate-400 ml-2">({lead.companyName})</span>}
                            </div>

                            <div className="flex items-center gap-2">
                              <select
                                value={lead.status}
                                onChange={async e => {
                                  await updateLead(lead.id, { status: e.target.value as any });
                                  loadData();
                                }}
                                className="bg-[#07090e] border border-white/12 rounded px-2.5 py-1 text-xs text-blue-400 font-mono"
                              >
                                <option value="NEW">NEW</option>
                                <option value="CONTACTED">CONTACTED</option>
                                <option value="CONSULTATION">CONSULTATION</option>
                                <option value="PROPOSAL">PROPOSAL</option>
                                <option value="NEGOTIATION">NEGOTIATION</option>
                                <option value="WON">WON</option>
                                <option value="LOST">LOST</option>
                              </select>

                              <button
                                onClick={async () => {
                                  const res = await syncLeadToSheets(lead.id);
                                  setNotification({ type: res.success ? 'success' : 'error', message: res.message });
                                  loadData();
                                }}
                                className="px-2.5 py-1 text-[11px] font-mono text-slate-300 hover:text-white bg-white/5 border border-white/10 rounded"
                              >
                                {lead.syncedToSheets ? 'Synced ✓' : 'Sync to Sheets'}
                              </button>
                            </div>
                          </div>

                          <div className="text-xs text-slate-400 flex flex-wrap gap-4">
                            <span>Phone: <strong className="text-white font-mono">{lead.phone}</strong></span>
                            <span>WhatsApp: <strong className="text-white font-mono">{lead.whatsapp}</strong></span>
                            <span>Email: <strong className="text-white">{lead.email}</strong></span>
                            <span>Service: <strong className="text-blue-300">{lead.serviceName}</strong></span>
                            <span>Budget: <strong className="text-emerald-300 font-mono">{lead.budget}</strong></span>
                          </div>

                          <div className="p-3 rounded-lg bg-white/2 border border-white/4 text-xs text-slate-300">
                            <strong>Requirements:</strong> {lead.requirements}
                          </div>

                          {/* Editable internal notes */}
                          <div className="flex items-center gap-2 pt-2">
                            <input
                              type="text"
                              defaultValue={lead.notes || ''}
                              onBlur={async e => {
                                if (e.target.value !== lead.notes) {
                                  await updateLead(lead.id, { notes: e.target.value });
                                  setNotification({ type: 'success', message: 'Lead note saved.' });
                                }
                              }}
                              placeholder="Add internal staff notes (press outside to save)..."
                              className="flex-1 bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB: BOOKINGS */}
              {activeTab === 'BOOKINGS' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white font-display">Consultation Bookings</h3>
                      <p className="text-xs text-slate-400">Real-time slots, holds, and double-booking reconciliation.</p>
                    </div>
                    <button onClick={loadData} className="p-2 text-slate-400 hover:text-white bg-[#0e131e] border border-white/10 rounded-lg">
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>

                  {bookings.length === 0 ? (
                    <div className="py-16 text-center text-xs text-slate-500 font-mono bg-[#0e131e] border border-white/8 rounded-xl">
                      NO BOOKINGS YET
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {bookings.map(b => (
                        <div key={b.id} className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div>
                              <span className="text-sm font-bold text-white">{b.customerName}</span>
                              <span className="text-xs font-mono text-blue-400 ml-3">Ref: {b.bookingReference}</span>
                            </div>

                            <div className="flex items-center gap-2">
                              <select
                                value={b.status}
                                onChange={async e => {
                                  await updateBooking(b.id, { status: e.target.value as any });
                                  loadData();
                                }}
                                className="bg-[#07090e] border border-white/12 rounded px-2.5 py-1 text-xs text-emerald-400 font-mono"
                              >
                                <option value="PENDING">PENDING</option>
                                <option value="CONFIRMED">CONFIRMED</option>
                                <option value="RESCHEDULED">RESCHEDULED</option>
                                <option value="COMPLETED">COMPLETED</option>
                                <option value="CANCELLED">CANCELLED</option>
                                <option value="NO_SHOW">NO_SHOW</option>
                                <option value="EXPIRED">EXPIRED</option>
                              </select>
                            </div>
                          </div>

                          <div className="text-xs text-slate-400 flex flex-wrap gap-4">
                            <span>Date: <strong className="text-white font-mono">{b.date}</strong></span>
                            <span>Time: <strong className="text-white font-mono">{b.startTime} - {b.endTime}</strong> ({b.timezone})</span>
                            <span>Service: <strong className="text-blue-300">{b.serviceName}</strong></span>
                            <span>Phone: <strong className="text-white font-mono">{b.customerPhone}</strong></span>
                            <span>Payment: <strong className="text-white font-mono uppercase">{b.paymentStatus}</strong></span>
                          </div>

                          <div className="text-xs text-slate-300 p-2.5 rounded bg-white/2 border border-white/4">
                            <strong>Requirements:</strong> {b.requirements}
                          </div>

                          {b.cancellationReason && (
                            <div className="text-xs text-red-300 p-2 rounded bg-red-500/10 border border-red-500/20">
                              <strong>Cancellation Reason:</strong> {b.cancellationReason}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB: PAYMENTS */}
              {activeTab === 'PAYMENTS' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-xl font-bold text-white font-display">Payment Transactions</h3>
                      <p className="text-xs text-slate-400">Server verified HMAC signatures. Truthful ledger records only.</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <select
                        value={paymentStatusFilter}
                        onChange={e => setPaymentStatusFilter(e.target.value)}
                        className="bg-[#0e131e] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                      >
                        <option value="ALL">All Statuses</option>
                        <option value="SUCCESS">SUCCESS</option>
                        <option value="PENDING">PENDING</option>
                        <option value="FAILED">FAILED</option>
                        <option value="REFUNDED">REFUNDED</option>
                        <option value="PARTIALLY_REFUNDED">PARTIALLY_REFUNDED</option>
                      </select>
                      <button onClick={loadData} className="p-2 text-slate-400 hover:text-white bg-[#0e131e] border border-white/10 rounded-lg">
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {payments.length === 0 ? (
                    <div className="py-16 text-center text-xs text-slate-500 font-mono bg-[#0e131e] border border-white/8 rounded-xl">
                      NO PAYMENT DATA YET
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {payments.map(p => (
                        <div key={p.id} className="p-5 rounded-xl border border-white/8 bg-[#0e131e] flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-white">{p.customerName || 'Customer'}</span>
                              <span className="text-xs font-mono text-slate-400">Order: {p.gatewayOrderId}</span>
                              <span className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                                p.status === 'SUCCESS' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                                p.status === 'FAILED' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                                'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                              }`}>
                                {p.status}
                              </span>
                            </div>
                            <div className="text-xs text-slate-400 mt-1">
                              Payment ID: <span className="font-mono text-slate-300">{p.gatewayPaymentId || 'N/A'}</span> · Date: {p.paidAt || p.createdAt}
                            </div>
                          </div>

                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <div className="text-base font-bold font-mono text-white">₹{p.amount.toLocaleString('en-IN')}</div>
                              <div className="text-[11px] text-slate-400">{p.gateway}</div>
                            </div>

                            {p.status === 'SUCCESS' && (
                              <button
                                onClick={async () => {
                                  const reason = prompt('Enter refund reason:');
                                  if (reason) {
                                    const res = await processPaymentRefund(p.id, undefined, reason);
                                    if (res.success) {
                                      setNotification({ type: 'success', message: 'Refund registered.' });
                                      loadData();
                                    }
                                  }
                                }}
                                className="px-3 py-1.5 text-xs text-red-400 hover:text-red-300 bg-red-500/10 border border-red-500/20 rounded-md"
                              >
                                Refund
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB: SERVICES & PRICING */}
              {activeTab === 'SERVICES' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">Services &amp; Pricing Management</h3>
                    <p className="text-xs text-slate-400">Display the supplied pricing exactly. Changes are logged and do not alter past bookings.</p>
                  </div>

                  <div className="space-y-4">
                    {services.map(s => (
                      <div key={s.id} className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-4">
                        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                          <div>
                            <span className="text-base font-bold text-white">{s.name}</span>
                            <span className="text-xs text-slate-400 ml-3">Slug: {s.slug}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-400">Price (INR):</span>
                            <input
                              type="number"
                              defaultValue={s.price}
                              onBlur={async e => {
                                const newP = Number(e.target.value);
                                if (newP !== s.price && newP > 0) {
                                  await updateService(s.id, { price: newP });
                                  setNotification({ type: 'success', message: `Price for ${s.name} updated to ₹${newP}.` });
                                  loadData();
                                }
                              }}
                              className="w-28 bg-[#07090e] border border-white/12 rounded px-2.5 py-1 text-sm text-white font-mono font-bold"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs text-slate-400 mb-1">Description</label>
                          <textarea
                            rows={2}
                            defaultValue={s.description}
                            onBlur={async e => {
                              if (e.target.value !== s.description) {
                                await updateService(s.id, { description: e.target.value });
                                setNotification({ type: 'success', message: `Description for ${s.name} updated.` });
                              }
                            }}
                            className="w-full bg-[#07090e] border border-white/10 rounded p-2 text-xs text-slate-300"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: TEAM MEMBERS */}
              {activeTab === 'TEAM' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">Team Directory</h3>
                    <p className="text-xs text-slate-400">Display only supplied team members: Vansh, Mayank, Aradhya, Sorta, Vivian. No invented credentials.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {teamMembers.map(m => (
                      <div key={m.id} className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <span className="text-base font-bold text-white">{m.name}</span>
                            <span className="text-xs text-blue-400 ml-2 font-mono">({m.role})</span>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs text-slate-400 mb-1">Bio</label>
                          <textarea
                            rows={2}
                            defaultValue={m.bio || ''}
                            onBlur={async e => {
                              if (e.target.value !== m.bio) {
                                await updateTeamMember(m.id, { bio: e.target.value });
                                setNotification({ type: 'success', message: `Bio for ${m.name} updated.` });
                              }
                            }}
                            className="w-full bg-[#07090e] border border-white/10 rounded p-2 text-xs text-slate-300"
                          />
                        </div>

                        <div>
                          <label className="block text-xs text-slate-400 mb-1">Skills (comma separated)</label>
                          <input
                            type="text"
                            defaultValue={m.skills.join(', ')}
                            onBlur={async e => {
                              const skills = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                              await updateTeamMember(m.id, { skills });
                              setNotification({ type: 'success', message: `Skills for ${m.name} updated.` });
                            }}
                            className="w-full bg-[#07090e] border border-white/10 rounded px-2.5 py-1 text-xs text-slate-300"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: REVIEWS */}
              {activeTab === 'REVIEWS' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">Client Reviews</h3>
                    <p className="text-xs text-slate-400">Strict rule: Never fabricate reviews. Only display verified client feedback.</p>
                  </div>

                  {reviews.length === 0 ? (
                    <div className="py-16 text-center text-xs text-slate-500 font-mono bg-[#0e131e] border border-white/8 rounded-xl">
                      NO REVIEWS YET
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {reviews.map(r => (
                        <div key={r.id} className="p-4 rounded-xl border border-white/8 bg-[#0e131e]">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-bold text-white">{r.reviewerName}</span>
                            <span className="text-xs text-amber-400">★ {r.rating}/5</span>
                          </div>
                          <p className="text-xs text-slate-300">{r.reviewText}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add verified review form */}
                  <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e] max-w-lg space-y-3">
                    <h4 className="text-sm font-semibold text-white">Add Verified Client Review</h4>
                    <input
                      type="text"
                      placeholder="Reviewer Name"
                      value={newReviewAuthor}
                      onChange={e => setNewReviewAuthor(e.target.value)}
                      className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                    />
                    <textarea
                      rows={3}
                      placeholder="Review Text"
                      value={newReviewText}
                      onChange={e => setNewReviewText(e.target.value)}
                      className="w-full bg-[#07090e] border border-white/10 rounded p-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (newReviewAuthor && newReviewText) {
                          await addReview({
                            reviewerName: newReviewAuthor,
                            reviewText: newReviewText,
                            rating: Number(newReviewRating),
                            isVerified: true,
                          });
                          setNewReviewAuthor('');
                          setNewReviewText('');
                          setNotification({ type: 'success', message: 'Verified review added.' });
                          loadData();
                        }
                      }}
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg"
                    >
                      Publish Verified Review
                    </button>
                  </div>
                </div>
              )}

              {/* TAB: FAQS */}
              {activeTab === 'FAQS' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">FAQ Management</h3>
                    <p className="text-xs text-slate-400">Curate factual answers for public customer inquiries.</p>
                  </div>

                  <div className="space-y-3">
                    {faqs.map(f => (
                      <div key={f.id} className="p-4 rounded-xl border border-white/8 bg-[#0e131e] space-y-2">
                        <div className="flex justify-between items-center">
                          <input
                            type="text"
                            defaultValue={f.question}
                            onBlur={async e => {
                              if (e.target.value !== f.question) {
                                await updateFAQ(f.id, { question: e.target.value });
                                setNotification({ type: 'success', message: 'FAQ question updated.' });
                              }
                            }}
                            className="w-full bg-transparent font-semibold text-white text-sm focus:outline-none"
                          />
                        </div>
                        <textarea
                          rows={2}
                          defaultValue={f.answer}
                          onBlur={async e => {
                            if (e.target.value !== f.answer) {
                              await updateFAQ(f.id, { answer: e.target.value });
                              setNotification({ type: 'success', message: 'FAQ answer updated.' });
                            }
                          }}
                          className="w-full bg-[#07090e] border border-white/10 rounded p-2 text-xs text-slate-300"
                        />
                      </div>
                    ))}
                  </div>

                  {/* Create New FAQ */}
                  <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e] max-w-lg space-y-3">
                    <h4 className="text-sm font-semibold text-white">Create New FAQ</h4>
                    <input
                      type="text"
                      placeholder="Question"
                      value={newFaqQ}
                      onChange={e => setNewFaqQ(e.target.value)}
                      className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                    />
                    <textarea
                      rows={2}
                      placeholder="Answer"
                      value={newFaqA}
                      onChange={e => setNewFaqA(e.target.value)}
                      className="w-full bg-[#07090e] border border-white/10 rounded p-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (newFaqQ && newFaqA) {
                          await createFAQ({ question: newFaqQ, answer: newFaqA });
                          setNewFaqQ('');
                          setNewFaqA('');
                          setNotification({ type: 'success', message: 'FAQ created.' });
                          loadData();
                        }
                      }}
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg"
                    >
                      Add FAQ
                    </button>
                  </div>
                </div>
              )}

              {/* TAB: PRE-LAUNCH CHECKLIST */}
              {activeTab === 'CHECKLIST' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                    <div>
                      <h3 className="text-xl font-bold text-white font-display">Pre-Launch Quality-Control Checklist</h3>
                      <p className="text-xs text-slate-400">Strict gatekeeper. Only shows 'READY TO LAUNCH' when all checks pass.</p>
                    </div>

                    <div className="flex items-center gap-3">
                      {allMandatoryPassed ? (
                        <span className="px-4 py-1.5 rounded-full text-xs font-bold font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse">
                          READY TO LAUNCH
                        </span>
                      ) : (
                        <span className="px-4 py-1.5 rounded-full text-xs font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20">
                          LAUNCH GATED · PENDING AUDIT
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {Object.entries(checklist).map(([itemKey, status]) => (
                      <div key={itemKey} className="p-4 rounded-xl border border-white/8 bg-[#0e131e] flex items-center justify-between gap-3">
                        <span className="text-xs font-medium text-slate-200">{itemKey}</span>
                        <select
                          value={status}
                          onChange={async e => {
                            await updateChecklistItem(itemKey, e.target.value);
                            loadData();
                          }}
                          className={`rounded px-2.5 py-1 text-xs font-mono border ${
                            status === 'COMPLETED' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                            status === 'IN PROGRESS' ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' :
                            status === 'NEEDS REVIEW' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
                            'bg-white/5 text-slate-400 border-white/10'
                          }`}
                        >
                          <option value="NOT STARTED">NOT STARTED</option>
                          <option value="IN PROGRESS">IN PROGRESS</option>
                          <option value="COMPLETED">COMPLETED</option>
                          <option value="NEEDS REVIEW">NEEDS REVIEW</option>
                        </select>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: SETTINGS & KEYS */}
              {activeTab === 'SETTINGS' && settings && (
                <div className="space-y-6 max-w-2xl">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">Platform &amp; Integration Settings</h3>
                    <p className="text-xs text-slate-400">Manage business information, Google Sheets, and Razorpay payment parameters.</p>
                  </div>

                  <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-4">
                    <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Business Coordinates</h4>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Business Name</label>
                      <input
                        type="text"
                        defaultValue={settings.businessName}
                        disabled
                        className="w-full bg-[#07090e] border border-white/8 rounded px-3 py-1.5 text-xs text-slate-400 cursor-not-allowed"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-slate-400 mb-1">Phone</label>
                        <input
                          type="text"
                          defaultValue={settings.phone}
                          onBlur={async e => {
                            await updateSettings({ phone: e.target.value });
                            setNotification({ type: 'success', message: 'Phone updated.' });
                          }}
                          className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-400 mb-1">WhatsApp</label>
                        <input
                          type="text"
                          defaultValue={settings.whatsapp}
                          onBlur={async e => {
                            await updateSettings({ whatsapp: e.target.value });
                            setNotification({ type: 'success', message: 'WhatsApp updated.' });
                          }}
                          className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Email</label>
                      <input
                        type="email"
                        defaultValue={settings.email}
                        onBlur={async e => {
                          await updateSettings({ email: e.target.value });
                          setNotification({ type: 'success', message: 'Email updated.' });
                        }}
                        className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-4">
                    <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Google Sheets Integration</h4>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Google Sheet ID</label>
                      <input
                        type="text"
                        defaultValue={settings.googleSheetId || ''}
                        placeholder="e.g. 1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                        onBlur={async e => {
                          const val = e.target.value.trim();
                          await updateSettings({ googleSheetId: val, googleSheetsConnected: Boolean(val) });
                          setNotification({ type: 'success', message: 'Google Sheet settings updated.' });
                          loadData();
                        }}
                        className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white font-mono"
                      />
                    </div>
                    <div className="text-xs text-slate-400">
                      Connection Status: {settings.googleSheetsConnected ? <span className="text-emerald-400 font-bold">CONNECTED</span> : <span className="text-amber-400 font-bold">GOOGLE SHEETS NOT CONNECTED</span>}
                    </div>
                  </div>

                  <div className="p-5 rounded-xl border border-white/8 bg-[#0e131e] space-y-4">
                    <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Razorpay Gateway</h4>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Razorpay Key ID</label>
                      <input
                        type="text"
                        defaultValue={settings.razorpayKeyId || ''}
                        placeholder="rzp_live_... or rzp_test_..."
                        onBlur={async e => {
                          await updateSettings({ razorpayKeyId: e.target.value.trim() });
                          setNotification({ type: 'success', message: 'Razorpay Key updated.' });
                        }}
                        className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: AUDIT LOGS */}
              {activeTab === 'AUDIT_LOGS' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-white font-display">System Audit Trail</h3>
                    <p className="text-xs text-slate-400">Immutable ledger of administrative actions, bookings, and payments.</p>
                  </div>

                  <div className="p-4 rounded-xl border border-white/8 bg-[#0e131e] overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-white/8 text-slate-400 uppercase tracking-wider font-mono">
                          <th className="py-2.5 px-3">Timestamp</th>
                          <th className="py-2.5 px-3">Action</th>
                          <th className="py-2.5 px-3">Entity</th>
                          <th className="py-2.5 px-3">User</th>
                          <th className="py-2.5 px-3">Details</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/4">
                        {auditLogs.map(log => (
                          <tr key={log.id} className="hover:bg-white/2">
                            <td className="py-2 px-3 font-mono text-slate-400 whitespace-nowrap">{log.createdAt}</td>
                            <td className="py-2 px-3 font-mono font-semibold text-blue-400">{log.action}</td>
                            <td className="py-2 px-3 text-white">{log.entity}</td>
                            <td className="py-2 px-3 text-slate-300">{log.adminUserName || 'System'}</td>
                            <td className="py-2 px-3 text-slate-400 font-mono text-[11px] max-w-xs truncate">
                              {JSON.stringify(log.metadata || {})}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>

      {/* Change Password Dialog Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#0e131e] border border-white/12 rounded-xl max-w-sm w-full p-6 shadow-2xl">
            <h4 className="text-base font-bold text-white mb-4">Change Admin Password</h4>
            <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  value={currentPass}
                  onChange={e => setCurrentPass(e.target.value)}
                  className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">New Password (Min 8 chars)</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={newPass}
                  onChange={e => setNewPass(e.target.value)}
                  className="w-full bg-[#07090e] border border-white/10 rounded px-3 py-1.5 text-white"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-white bg-blue-600 rounded-md font-semibold"
                >
                  Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
