import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { FAQ } from '../types';

interface FAQSectionProps {
  faqs: FAQ[];
}

export const FAQSection: React.FC<FAQSectionProps> = ({ faqs }) => {
  const [openIds, setOpenIds] = useState<string[]>([faqs[0]?.id || 'faq_01']);
  const [activeCategory, setActiveCategory] = useState<string>('ALL');

  const categories = ['ALL', ...Array.from(new Set(faqs.map(f => f.category)))];

  const filteredFaqs = faqs.filter(f => {
    if (activeCategory === 'ALL') return true;
    return f.category === activeCategory;
  });

  const toggleFAQ = (id: string) => {
    setOpenIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <section
      id="faq"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="Frequently Asked Questions"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <HelpCircle className="w-4 h-4" aria-hidden="true" />
            <span>Clear Explanations</span>
            <span aria-hidden="true">·</span>
            <span>Fact-Checked</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Frequently Asked Questions.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Essential facts about our web and app engineering processes, verified rates, real consultation booking, and business operations.
          </p>
        </div>

        {/* Category Filter Controls */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-8" role="tablist">
          {categories.map(cat => (
            <button
              key={cat}
              type="button"
              role="tab"
              aria-selected={activeCategory === cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeCategory === cat
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'bg-[#0d121c] text-slate-400 hover:text-white border border-white/8'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Accordion List */}
        <div className="max-w-3xl space-y-3">
          {filteredFaqs.map(faq => {
            const isOpen = openIds.includes(faq.id);
            const questionId = `faq-q-${faq.id}`;
            const answerId = `faq-a-${faq.id}`;

            return (
              <div
                key={faq.id}
                className="rounded-xl border border-white/8 bg-[#0a0e17] overflow-hidden transition-colors"
              >
                <h3>
                  <button
                    type="button"
                    id={questionId}
                    aria-expanded={isOpen}
                    aria-controls={answerId}
                    onClick={() => toggleFAQ(faq.id)}
                    className="w-full py-4.5 px-5 text-left text-sm sm:text-base font-semibold text-white flex items-center justify-between gap-4 hover:text-blue-400 transition-colors focus-visible:outline-none"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                        isOpen ? 'rotate-180 text-blue-400' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                </h3>

                {isOpen && (
                  <div
                    id={answerId}
                    role="region"
                    aria-labelledby={questionId}
                    className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-white/4"
                  >
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
