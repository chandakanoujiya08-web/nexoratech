import React, { useState, useEffect } from 'react';
import { Calendar, Clock, CheckCircle2, AlertCircle, ArrowRight, RotateCcw, XCircle, CreditCard, ShieldCheck } from 'lucide-react';
import { Service, Booking } from '../types';
import { fetchAvailability, submitBooking, reschedulePublicBooking, cancelPublicBooking, createPaymentOrder, verifyPayment } from '../lib/api';

interface ConsultationBookingProps {
  services: Service[];
  initialServiceId?: string;
  onClose?: () => void;
}

export const ConsultationBooking: React.FC<ConsultationBookingProps> = ({
  services,
  initialServiceId,
}) => {
  const [activeTab, setActiveTab] = useState<'NEW_BOOKING' | 'MANAGE_BOOKING'>('NEW_BOOKING');

  // Form State
  const [selectedServiceId, setSelectedServiceId] = useState<string>(initialServiceId || services[0]?.id || 'srv_web_dev');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    // Tomorrow by default
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [requirements, setRequirements] = useState('');
  const [advancePaymentOption, setAdvancePaymentOption] = useState<boolean>(false);

  // Availability State
  const [slots, setSlots] = useState<{ time: string; available: boolean; reason?: string }[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [availabilityError, setAvailabilityError] = useState<string | null>(null);

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState<Booking | null>(null);
  const [bookingError, setBookingError] = useState<string | null>(null);

  // Manage Booking State
  const [manageRef, setManageRef] = useState('');
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleTime, setRescheduleTime] = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [manageFeedback, setManageFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [manageLoading, setManageLoading] = useState(false);

  // Load availability when selectedDate changes
  useEffect(() => {
    if (!selectedDate) return;
    setLoadingSlots(true);
    setAvailabilityError(null);
    setSelectedTime('');

    fetchAvailability(selectedDate)
      .then(res => {
        setSlots(res.slots);
      })
      .catch(err => {
        setAvailabilityError('Failed to load slots for this date. Please check your network connection.');
      })
      .finally(() => {
        setLoadingSlots(false);
      });
  }, [selectedDate]);

  // Handle Form Submit
  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !email.trim() || !selectedDate || !selectedTime) {
      setBookingError('Please complete all mandatory fields and pick an available time slot.');
      return;
    }

    setIsSubmitting(true);
    setBookingError(null);

    try {
      const res = await submitBooking({
        name,
        phone,
        whatsapp: whatsapp || phone,
        email,
        serviceId: selectedServiceId,
        date: selectedDate,
        startTime: selectedTime,
        requirements,
        companyName,
        advancePaymentRequired: advancePaymentOption,
      });

      setBookingSuccess(res.booking);

      // If advance payment was selected, initialize Razorpay checkout flow
      if (advancePaymentOption && res.booking) {
        try {
          const selectedService = services.find(s => s.id === selectedServiceId);
          const advanceAmount = selectedService ? Math.min(selectedService.price, 499) : 499;
          const orderRes = await createPaymentOrder(res.booking.id, advanceAmount);

          if (orderRes.success && (window as any).Razorpay) {
            const rzp = new (window as any).Razorpay({
              key: orderRes.order.keyId,
              amount: orderRes.order.amount,
              currency: 'INR',
              name: 'Nexora Technologies',
              description: `Consultation Advance - Ref: ${res.booking.bookingReference}`,
              order_id: orderRes.order.id,
              handler: async function (response: any) {
                try {
                  await verifyPayment({
                    razorpay_order_id: response.razorpay_order_id,
                    razorpay_payment_id: response.razorpay_payment_id,
                    razorpay_signature: response.razorpay_signature,
                    bookingId: res.booking.id,
                  });
                  setBookingSuccess(prev => prev ? { ...prev, paymentStatus: 'PAID', status: 'CONFIRMED' } : prev);
                } catch (verifyErr: any) {
                  setBookingError('Payment was captured by gateway, but server verification is reconciling. Reference recorded.');
                }
              },
              prefill: {
                name,
                email,
                contact: phone,
              },
              theme: {
                color: '#2563eb',
              },
            });
            rzp.open();
          }
        } catch (payErr) {
          console.warn('Razorpay checkout initialization skipped or simulated mode.');
        }
      }
    } catch (err: any) {
      setBookingError(err.message || 'Booking submission failed. Please try another slot.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReschedule = async () => {
    if (!manageRef.trim() || !rescheduleDate || !rescheduleTime) {
      setManageFeedback({ type: 'error', message: 'Enter your Booking Reference, new date, and new slot.' });
      return;
    }
    setManageLoading(true);
    setManageFeedback(null);
    try {
      const res = await reschedulePublicBooking({
        bookingReference: manageRef.trim(),
        date: rescheduleDate,
        startTime: rescheduleTime,
      });
      setManageFeedback({
        type: 'success',
        message: `Booking ${res.booking.bookingReference} successfully rescheduled to ${res.booking.date} at ${res.booking.startTime}.`,
      });
    } catch (err: any) {
      setManageFeedback({ type: 'error', message: err.message || 'Rescheduling failed.' });
    } finally {
      setManageLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!manageRef.trim()) {
      setManageFeedback({ type: 'error', message: 'Please enter your Booking Reference.' });
      return;
    }
    setManageLoading(true);
    setManageFeedback(null);
    try {
      const res = await cancelPublicBooking({
        bookingReference: manageRef.trim(),
        reason: cancelReason.trim() || 'Customer requested cancellation via portal',
      });
      setManageFeedback({
        type: 'success',
        message: `Booking ${res.booking.bookingReference} has been cancelled.`,
      });
    } catch (err: any) {
      setManageFeedback({ type: 'error', message: err.message || 'Cancellation failed.' });
    } finally {
      setManageLoading(false);
    }
  };

  return (
    <section
      id="booking"
      className="py-24 border-t border-white/6 bg-[#07090e] relative"
      aria-label="Consultation and Booking"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <span>Direct Access</span>
            <span aria-hidden="true">·</span>
            <span>Real Availability</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Schedule a Technical Consultation.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Reserve dedicated 1-on-1 time with our engineering team. Slots are real-time, concurrency-guaranteed, and held without double booking.
          </p>
        </div>

        {/* Tab Toggle (Interactive Filter Control) */}
        <div className="flex items-center gap-1 p-1 bg-[#0d121c] border border-white/8 rounded-lg max-w-sm mb-10">
          <button
            type="button"
            onClick={() => setActiveTab('NEW_BOOKING')}
            className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'NEW_BOOKING'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            New Consultation
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('MANAGE_BOOKING')}
            className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'MANAGE_BOOKING'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Manage Existing Booking
          </button>
        </div>

        {/* TAB 1: NEW BOOKING */}
        {activeTab === 'NEW_BOOKING' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Form & Service Details (7 cols) */}
            <div className="lg:col-span-7 bg-[#0d121c] border border-white/8 rounded-xl p-6 sm:p-8">
              
              {bookingSuccess ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8" aria-hidden="true" />
                  </div>
                  <h3 className="text-2xl font-bold text-white font-display">
                    Consultation Reserved Successfully
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto">
                    Your consultation slot has been locked in Asia/Kolkata timezone. A calendar notification and team alert have been generated.
                  </p>

                  <div className="p-4 rounded-lg bg-white/4 border border-white/8 text-left max-w-md mx-auto text-xs space-y-2 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Reference:</span>
                      <span className="text-blue-400 font-bold">{bookingSuccess.bookingReference}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Date &amp; Time:</span>
                      <span className="text-white">{bookingSuccess.date} at {bookingSuccess.startTime} (Asia/Kolkata)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Service:</span>
                      <span className="text-white">{bookingSuccess.serviceName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Status:</span>
                      <span className="text-emerald-400 uppercase">{bookingSuccess.status}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Payment:</span>
                      <span className="text-white uppercase">{bookingSuccess.paymentStatus}</span>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setBookingSuccess(null);
                        setSelectedTime('');
                      }}
                      className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all"
                    >
                      Book Another Consultation
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleBookingSubmit} className="space-y-6">
                  
                  {bookingError && (
                    <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-start gap-2.5">
                      <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" aria-hidden="true" />
                      <span>{bookingError}</span>
                    </div>
                  )}

                  {/* 1. Service Selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                      1. Required Service
                    </label>
                    <select
                      value={selectedServiceId}
                      onChange={e => setSelectedServiceId(e.target.value)}
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none"
                    >
                      {services.map(s => (
                        <option key={s.id} value={s.id}>
                          {s.name} — ₹{s.price.toLocaleString('en-IN')} ({s.pricingType === 'ONE_TIME' ? 'one-time' : 'monthly'})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 2. Customer Contact */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={e => setName(e.target.value)}
                        placeholder="e.g. Rahul Sharma"
                        className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        placeholder="name@company.com"
                        className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={e => setPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        WhatsApp Number (Optional)
                      </label>
                      <input
                        type="tel"
                        value={whatsapp}
                        onChange={e => setWhatsapp(e.target.value)}
                        placeholder="Same as phone or custom"
                        className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Company / Organization Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={e => setCompanyName(e.target.value)}
                      placeholder="e.g. Acme Tech Solutions"
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  {/* 3. Project Requirements */}
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Consultation Topic &amp; Requirements *
                    </label>
                    <textarea
                      rows={3}
                      required
                      value={requirements}
                      onChange={e => setRequirements(e.target.value)}
                      placeholder="Describe what you want to build, existing infrastructure, or technical questions..."
                      className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  {/* 4. Advance Payment Option */}
                  <label className="flex items-start gap-3 p-3.5 rounded-lg border border-white/8 bg-white/2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={advancePaymentOption}
                      onChange={e => setAdvancePaymentOption(e.target.checked)}
                      className="w-4 h-4 rounded border-slate-700 text-blue-600 focus:ring-blue-500 bg-[#07090e] mt-0.5"
                    />
                    <div className="text-xs">
                      <span className="font-semibold text-white">Hold slot with optional advance payment (₹499)</span>
                      <p className="text-slate-400 mt-0.5">
                        Secures highest priority slot lock via Razorpay gateway. If skipped, consultation remains scheduled with zero advance requirement.
                      </p>
                    </div>
                  </label>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting || !selectedTime}
                    className="w-full py-3.5 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <span>Verifying slot &amp; confirming...</span>
                    ) : (
                      <>
                        <span>Confirm Consultation for {selectedDate} at {selectedTime || '...'}</span>
                        <ArrowRight className="w-4 h-4" aria-hidden="true" />
                      </>
                    )}
                  </button>

                </form>
              )}

            </div>

            {/* Live Availability Picker (5 cols) */}
            <div className="lg:col-span-5 bg-[#0d121c] border border-white/8 rounded-xl p-6 sm:p-8">
              <div className="flex items-center justify-between pb-4 border-b border-white/8 mb-6">
                <div className="flex items-center gap-2 text-xs font-semibold text-white uppercase tracking-wider">
                  <Calendar className="w-4 h-4 text-blue-400" aria-hidden="true" />
                  <span>Real-Time Calendar</span>
                </div>
                <span className="text-xs font-mono text-slate-400">Asia/Kolkata</span>
              </div>

              {/* Date Input */}
              <div className="mb-6">
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  Select Preferred Date
                </label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={selectedDate}
                  onChange={e => setSelectedDate(e.target.value)}
                  className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                />
              </div>

              {/* Slots List */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-slate-300">
                    Available Time Slots (1-Hour Sessions)
                  </span>
                  {loadingSlots && <span className="text-xs text-blue-400">Checking availability...</span>}
                </div>

                {availabilityError ? (
                  <div className="p-3 rounded-lg bg-red-500/10 text-red-300 text-xs">
                    {availabilityError}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
                    {slots.map(s => {
                      const isSelected = selectedTime === s.time;
                      return (
                        <button
                          key={s.time}
                          type="button"
                          disabled={!s.available}
                          onClick={() => setSelectedTime(s.time)}
                          className={`py-2 px-2.5 rounded-lg text-xs font-mono tabular-nums transition-all border text-center ${
                            isSelected
                              ? 'border-blue-500 bg-blue-600 text-white font-bold'
                              : s.available
                              ? 'border-white/10 bg-white/2 text-slate-200 hover:border-blue-500/40 hover:bg-white/5'
                              : 'border-white/4 bg-white/1 text-slate-600 cursor-not-allowed line-through'
                          }`}
                        >
                          {s.time} {s.reason === 'BOOKED' ? '(Reserved)' : s.reason === 'PAST' ? '(Past)' : ''}
                        </button>
                      );
                    })}
                  </div>
                )}

                <div className="mt-6 pt-4 border-t border-white/6 text-xs text-slate-400 space-y-1.5 leading-relaxed">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" aria-hidden="true" />
                    <span>Real-time availability directly verified on backend.</span>
                  </div>
                  <div>Slots marked line-through are confirmed bookings and cannot be selected.</div>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: MANAGE EXISTING BOOKING (Reschedule / Cancel) */}
        {activeTab === 'MANAGE_BOOKING' && (
          <div className="max-w-2xl bg-[#0d121c] border border-white/8 rounded-xl p-6 sm:p-8 space-y-6">
            <h3 className="text-lg font-bold text-white font-display">
              Reschedule or Cancel a Consultation
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enter your booking reference code (e.g. NEX-123456-ABCD) provided upon confirmation to modify your appointment.
            </p>

            {manageFeedback && (
              <div
                className={`p-4 rounded-lg text-xs flex items-start gap-2.5 ${
                  manageFeedback.type === 'success'
                    ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-300'
                    : 'bg-red-500/10 border border-red-500/20 text-red-300'
                }`}
              >
                {manageFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                )}
                <span>{manageFeedback.message}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Booking Reference Code *
              </label>
              <input
                type="text"
                required
                value={manageRef}
                onChange={e => setManageRef(e.target.value.toUpperCase())}
                placeholder="e.g. NEX-492810-F3A1"
                className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none font-mono"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  New Date (for Rescheduling)
                </label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={rescheduleDate}
                  onChange={e => setRescheduleDate(e.target.value)}
                  className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  New Time Slot
                </label>
                <select
                  value={rescheduleTime}
                  onChange={e => setRescheduleTime(e.target.value)}
                  className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                >
                  <option value="">Select slot</option>
                  {['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'].map(t => (
                    <option key={t} value={t}>{t} (Asia/Kolkata)</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Cancellation Reason (if requesting cancellation)
              </label>
              <input
                type="text"
                value={cancelReason}
                onChange={e => setCancelReason(e.target.value)}
                placeholder="Reason for cancellation..."
                className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-3">
              <button
                type="button"
                disabled={manageLoading || !manageRef || !rescheduleDate || !rescheduleTime}
                onClick={handleReschedule}
                className="flex-1 py-2.5 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-all flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Reschedule Booking</span>
              </button>

              <button
                type="button"
                disabled={manageLoading || !manageRef}
                onClick={handleCancel}
                className="py-2.5 px-4 text-xs font-medium text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-all flex items-center justify-center gap-1.5"
              >
                <XCircle className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Cancel Booking</span>
              </button>
            </div>

          </div>
        )}

      </div>
    </section>
  );
};
