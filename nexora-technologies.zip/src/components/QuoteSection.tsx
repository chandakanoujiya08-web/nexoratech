import React, { useState } from 'react';
import { FileText, Send, CheckCircle2, MessageSquare, AlertCircle, ArrowUpRight } from 'lucide-react';
import { Service } from '../types';
import { submitQuote } from '../lib/api';

interface QuoteSectionProps {
  services: Service[];
  preselectedServiceId?: string;
  onClose?: () => void;
}

export const QuoteSection: React.FC<QuoteSectionProps> = ({
  services,
  preselectedServiceId,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [business, setBusiness] = useState('');
  const [serviceId, setServiceId] = useState(preselectedServiceId || services[0]?.id || 'srv_web_dev');
  const [requirements, setRequirements] = useState('');
  const [budget, setBudget] = useState('Standard Verified Pricing');
  const [timeline, setTimeline] = useState('Immediate (Next 1-2 weeks)');

  const [loading, setLoading] = useState(false);
  const [successData, setSuccessData] = useState<{ message: string; leadId: string; whatsappUrl: string; sheetsStatus?: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !email.trim() || !requirements.trim()) {
      setError('Please provide your name, phone, email, and requirements.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await submitQuote({
        name,
        phone,
        whatsapp: whatsapp || phone,
        email,
        business,
        serviceId,
        requirements,
        budget,
        timeline,
      });

      setSuccessData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to submit quote request. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      id="quote"
      className="py-24 border-t border-white/6 bg-[#080c14] relative"
      aria-label="Request a Custom Project Quote"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-400 mb-3">
            <FileText className="w-4 h-4" aria-hidden="true" />
            <span>Structured Estimation</span>
            <span aria-hidden="true">·</span>
            <span>Direct Pipeline</span>
          </div>
          <h2
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display mb-4"
            style={{ textWrap: 'balance' }}
          >
            Request a Project Quote.
          </h2>
          <p className="text-base text-slate-400 leading-relaxed">
            Provide your application specifications. Your submission immediately routes to our lead-management CRM, initiates automated sheets sync, and unlocks direct WhatsApp coordination.
          </p>
        </div>

        {/* Content Box */}
        <div className="max-w-3xl mx-auto bg-[#0d121c] border border-white/8 rounded-xl p-6 sm:p-10">
          
          {successData ? (
            <div className="py-6 text-center space-y-5">
              <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" aria-hidden="true" />
              </div>

              <h3 className="text-2xl font-bold text-white font-display">
                Quote Request Registered
              </h3>

              <p className="text-sm text-slate-300 max-w-lg mx-auto leading-relaxed">
                {successData.message}
              </p>

              {/* Truthful Google Sheets Sync Status Notification */}
              {successData.sheetsStatus && (
                <div className="p-3 rounded-lg bg-white/4 border border-white/8 max-w-md mx-auto text-xs text-slate-400 font-mono">
                  Integration Sync: <span className="text-blue-300">{successData.sheetsStatus}</span>
                </div>
              )}

              {/* Direct WhatsApp CTA Button with Prefilled Project Context */}
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <a
                  href={successData.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-6 py-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-md transition-all flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <MessageSquare className="w-4 h-4" aria-hidden="true" />
                  <span>Continue on WhatsApp with Lead #{successData.leadId.slice(-6)}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                </a>

                <button
                  type="button"
                  onClick={() => {
                    setSuccessData(null);
                    setRequirements('');
                  }}
                  className="w-full sm:w-auto px-5 py-3 text-xs font-medium text-slate-300 hover:text-white bg-white/5 border border-white/10 rounded-lg transition-all"
                >
                  Submit Another Inquiry
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {error && (
                <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" aria-hidden="true" />
                  <span>{error}</span>
                </div>
              )}

              {/* Grid 1: Name & Business */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Priya Patel"
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Business / Startup Name
                  </label>
                  <input
                    type="text"
                    value={business}
                    onChange={e => setBusiness(e.target.value)}
                    placeholder="e.g. Vapi Logistics Ltd."
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Grid 2: Phone & WhatsApp & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+91 99248 XXXXX"
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    WhatsApp Number
                  </label>
                  <input
                    type="tel"
                    value={whatsapp}
                    onChange={e => setWhatsapp(e.target.value)}
                    placeholder="Same as phone or custom"
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="priya@domain.com"
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Grid 3: Service & Budget & Timeline */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Required Service *
                  </label>
                  <select
                    value={serviceId}
                    onChange={e => setServiceId(e.target.value)}
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                  >
                    {services.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} (₹{s.price.toLocaleString('en-IN')})
                      </option>
                    ))}
                    <option value="custom">Custom Web &amp; App Hybrid</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Estimated Budget Range
                  </label>
                  <select
                    value={budget}
                    onChange={e => setBudget(e.target.value)}
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                  >
                    <option value="₹2,999 - ₹7,999">₹2,999 - ₹7,999 (Single Platform)</option>
                    <option value="₹10,000 - ₹25,000">₹10,000 - ₹25,000 (Cross Platform + Ads)</option>
                    <option value="₹25,000+">₹25,000+ (Custom Enterprise Solution)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Target Timeline
                  </label>
                  <select
                    value={timeline}
                    onChange={e => setTimeline(e.target.value)}
                    className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                  >
                    <option value="Immediate (Next 1-2 weeks)">Immediate (Next 1-2 weeks)</option>
                    <option value="Within 1 month">Within 1 month</option>
                    <option value="Planning for next quarter">Planning for next quarter</option>
                  </select>
                </div>
              </div>

              {/* Requirements Description */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Detailed Project Requirements *
                </label>
                <textarea
                  rows={4}
                  required
                  value={requirements}
                  onChange={e => setRequirements(e.target.value)}
                  placeholder="Outline feature specifications, target user flows, desired integrations, or reference systems..."
                  className="w-full bg-[#07090e] border border-white/12 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2 whitespace-nowrap"
              >
                {loading ? (
                  <span>Processing &amp; Registering Lead...</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" aria-hidden="true" />
                    <span>Submit Project Quote Request</span>
                  </>
                )}
              </button>

            </form>
          )}

        </div>

      </div>
    </section>
  );
};
