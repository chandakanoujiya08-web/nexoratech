import React from 'react';
import { Lock, Phone, MessageSquare, Mail, MapPin, Clock } from 'lucide-react';
import { PolicyType } from './LegalModals';

interface FooterProps {
  onOpenPolicy: (type: PolicyType) => void;
  onOpenAdmin: () => void;
  business: {
    name: string;
    positioning: string;
    location: string;
    exactAddress?: string | null;
    phone: string;
    whatsapp: string;
    email: string;
    businessHours: string;
  };
}

export const Footer: React.FC<FooterProps> = ({ onOpenPolicy, onOpenAdmin, business }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-white/8 bg-[#05070a] text-slate-400 py-16" aria-label="Site Footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/6">
          
          {/* Brand & Positioning (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <a
              href="/"
              className="text-xl font-bold tracking-tight text-white font-display inline-block"
            >
              {business.name}
            </a>
            <p className="text-sm text-slate-300 font-medium">
              {business.positioning}
            </p>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Delivering high-performance web development, mobile applications, and digital systems built with uncompromising technical rigor. Founded 2026.
            </p>
          </div>

          {/* Quick Navigation */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-white uppercase tracking-wider">
              Navigation
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#about" className="hover:text-white transition-colors">About Company</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Services &amp; Pricing</a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-white transition-colors">Pricing Calculator</a>
              </li>
              <li>
                <a href="#technology" className="hover:text-white transition-colors">Technology Journey</a>
              </li>
              <li>
                <a href="#team" className="hover:text-white transition-colors">Core Team</a>
              </li>
              <li>
                <a href="#booking" className="hover:text-white transition-colors">Book Consultation</a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-white uppercase tracking-wider">
              Contact Channels
            </div>
            <ul className="space-y-2.5 text-xs">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" aria-hidden="true" />
                <a href={`tel:${business.phone.replace(/[^\d]/g, '')}`} className="hover:text-white font-mono">
                  {business.phone}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
                <a
                  href={`https://wa.me/${business.whatsapp.replace(/[^\d]/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white font-mono"
                >
                  WhatsApp: {business.whatsapp}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-cyan-400 shrink-0" aria-hidden="true" />
                <a href={`mailto:${business.email}`} className="hover:text-white break-all">
                  {business.email}
                </a>
              </li>
            </ul>
          </div>

          {/* Location & Hours */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-white uppercase tracking-wider">
              Headquarters
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{business.exactAddress || business.location}</span>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{business.businessHours} Operational Cycle</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Legal & Discreet Admin Portal */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div>
            © {currentYear} {business.name}. All rights reserved.
          </div>

          <div className="flex flex-wrap items-center gap-4 text-slate-400">
            <button
              onClick={() => onOpenPolicy('PRIVACY')}
              className="hover:text-white transition-colors"
            >
              Privacy Policy
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => onOpenPolicy('TERMS')}
              className="hover:text-white transition-colors"
            >
              Terms of Service
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => onOpenPolicy('REFUND')}
              className="hover:text-white transition-colors"
            >
              Cancellation &amp; Refund
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 hover:text-blue-400 transition-colors py-1 px-2 rounded bg-white/3 border border-white/6"
              aria-label="Access Admin Management Portal"
            >
              <Lock className="w-3 h-3 text-slate-400" aria-hidden="true" />
              <span>Admin Portal</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
