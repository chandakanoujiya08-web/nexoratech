import React from 'react';
import { X, Shield, FileText, RefreshCw } from 'lucide-react';

export type PolicyType = 'PRIVACY' | 'TERMS' | 'REFUND' | null;

interface LegalModalsProps {
  activePolicy: PolicyType;
  onClose: () => void;
}

export const LegalModals: React.FC<LegalModalsProps> = ({ activePolicy, onClose }) => {
  if (!activePolicy) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="legal-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      <div className="bg-[#0e131d] border border-white/12 rounded-xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/8 bg-[#090d15]">
          <div className="flex items-center gap-2.5">
            {activePolicy === 'PRIVACY' && <Shield className="w-5 h-5 text-blue-400" />}
            {activePolicy === 'TERMS' && <FileText className="w-5 h-5 text-cyan-400" />}
            {activePolicy === 'REFUND' && <RefreshCw className="w-5 h-5 text-emerald-400" />}
            <h2 id="legal-modal-title" className="text-base font-bold text-white font-display">
              {activePolicy === 'PRIVACY' && 'Privacy Policy & Data Security'}
              {activePolicy === 'TERMS' && 'Terms of Service'}
              {activePolicy === 'REFUND' && 'Cancellation & Refund Policy'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors focus-visible:outline-none"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto text-xs sm:text-sm text-slate-300 space-y-4 leading-relaxed">
          {activePolicy === 'PRIVACY' && (
            <>
              <p>
                <strong>Effective Date:</strong> Founded 2026. Nexora Technologies (headquartered in Vapi, Gujarat, India) respects your privacy and is committed to protecting your personal information.
              </p>
              <h3 className="text-white font-semibold text-sm">1. Information We Collect</h3>
              <p>
                We collect only information strictly necessary to process your consultation bookings, deliver custom software engineering, fulfill quote estimates, and provide technical client support:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-slate-400">
                <li>Contact details: Name, verified email address, telephone, and WhatsApp number.</li>
                <li>Project requirements, budget indications, and business company names.</li>
                <li>Transactional references and timestamps associated with consultations or services.</li>
              </ul>
              <h3 className="text-white font-semibold text-sm">2. Zero Payment Secret Storage</h3>
              <p>
                Nexora Technologies does NOT store, log, or process credit card numbers, CVVs, UPI PINs, or net banking passwords. All online payments are securely executed through certified payment gateway partners (such as Razorpay) complying with PCI-DSS protocols.
              </p>
              <h3 className="text-white font-semibold text-sm">3. Data Protection &amp; Security</h3>
              <p>
                All data transmission between your browser and our platform is encrypted via HTTPS with modern TLS protocols. Access to administrative systems is safeguarded with server-side authentication, salted password hashing (scrypt), and comprehensive audit trails.
              </p>
              <h3 className="text-white font-semibold text-sm">4. Data Subject Rights &amp; Deletion</h3>
              <p>
                You may request a copy of your records or demand deletion of your contact data from our active CRM database by writing to our data contact at <strong>vanitakanojia25@gmail.com</strong>.
              </p>
            </>
          )}

          {activePolicy === 'TERMS' && (
            <>
              <p>
                <strong>Last Updated:</strong> 2026. These Terms of Service govern your relationship with Nexora Technologies for all software engineering, consultation bookings, and technical insurance packages.
              </p>
              <h3 className="text-white font-semibold text-sm">1. Scope of Work &amp; Pricing</h3>
              <p>
                All services are delivered according to the agreed deliverables stated at the time of project initiation. The rates displayed on our platform (Web Development ₹2,999, App Development ₹7,999, Web Insurance ₹499, App Insurance ₹999, Meta Ads ₹20,000) are transparent, and clients are charged the exact fee applied when the order or contract was created.
              </p>
              <h3 className="text-white font-semibold text-sm">2. Client Cooperation &amp; Intellectual Property</h3>
              <p>
                Upon receipt of full payment for bespoke custom software, ownership of the resulting custom source code is transferred to the client, excluding any underlying open-source libraries or third-party proprietary frameworks.
              </p>
              <h3 className="text-white font-semibold text-sm">3. Hosting, Domains &amp; Third-Party Services</h3>
              <p>
                Third-party fees (domain registrars, cloud infrastructure providers, Meta advertising budgets) remain the financial responsibility of the client and are paid directly to the respective external vendors.
              </p>
            </>
          )}

          {activePolicy === 'REFUND' && (
            <>
              <p>
                <strong>Nexora Technologies Cancellation &amp; Refund Policy.</strong>
              </p>
              <h3 className="text-white font-semibold text-sm">1. Consultation Rescheduling &amp; Cancellation</h3>
              <p>
                Consultations may be rescheduled or cancelled through our online booking portal using your unique Booking Reference number at least 2 hours prior to the scheduled session.
              </p>
              <h3 className="text-white font-semibold text-sm">2. Advance Payment Reconciliation</h3>
              <p>
                In the rare event that payment was captured successfully by our payment gateway but an unexpected system concurrency error prevented slot confirmation, our server enters a reconciliation state and notifies administrators. The client will be offered an immediate prioritized slot confirmation or a full refund.
              </p>
              <h3 className="text-white font-semibold text-sm">3. Milestone-Based Service Refunds</h3>
              <p>
                Because custom software development involves dedicated engineering time from our developers and designers, fees for milestones that have already received customer approval are non-refundable. Any disputed advance payments may be reviewed by contacting vanitakanojia25@gmail.com.
              </p>
            </>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-white/8 bg-[#090d15] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
          >
            I Understand &amp; Agree
          </button>
        </div>

      </div>
    </div>
  );
};
