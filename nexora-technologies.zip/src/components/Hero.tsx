import React from 'react';
import { ArrowUpRight, MessageSquare, ChevronDown } from 'lucide-react';
import { ThreeHeroCanvas } from './ThreeHeroCanvas';
import { trackAnalytics } from '../lib/api';

interface HeroProps {
  onOpenBooking: () => void;
  onOpenQuote: () => void;
  whatsappNumber: string;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking, onOpenQuote, whatsappNumber }) => {
  const cleanPhone = whatsappNumber.replace(/[^\d]/g, '');
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(
    'Hello Nexora Technologies, I would like to discuss a website/app project.'
  )}`;

  const handleBookingClick = () => {
    trackAnalytics('hero_cta_booking');
    onOpenBooking();
  };

  const handleExploreClick = () => {
    trackAnalytics('hero_cta_explore_services');
    const el = document.getElementById('services');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleWhatsAppClick = () => {
    trackAnalytics('hero_cta_whatsapp');
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  const handleQuoteClick = () => {
    trackAnalytics('hero_cta_quote');
    onOpenQuote();
  };

  return (
    <section
      id="hero"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden"
      aria-label="Introduction & Value Proposition"
    >
      {/* 3D Cinematic Canvas & Volumetric Environment */}
      <ThreeHeroCanvas />

      {/* Hero Content Overlay */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        
        {/* Location Indicator (Clean unboxed text metadata with typographic separators) */}
        <div className="flex items-center gap-2.5 text-xs font-medium tracking-widest uppercase text-slate-400 mb-6">
          <span>Vapi</span>
          <span aria-hidden="true" className="text-blue-500">·</span>
          <span>Gujarat</span>
          <span aria-hidden="true" className="text-blue-500">·</span>
          <span>India</span>
        </div>

        {/* Primary Headline */}
        <h1
          className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-white font-display mb-6 leading-[1.08]"
          style={{ textWrap: 'balance' }}
        >
          INNOVATING WEB &amp; APP SOLUTIONS FOR TOMORROW.
        </h1>

        {/* Value Proposition Description */}
        <p className="max-w-2xl text-base sm:text-lg text-slate-300 font-normal mb-10 leading-relaxed">
          High-performance digital engineering for individuals, startups, and growing enterprises.
          Transparent pricing, zero simulated data, and robust production-ready architectures built in Gujarat.
        </p>

        {/* Primary and Secondary CTA Row */}
        <div className="flex flex-wrap items-center justify-center gap-3.5 w-full max-w-md sm:max-w-none">
          {/* Primary CTA */}
          <button
            onClick={handleBookingClick}
            className="w-full sm:w-auto px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-lg shadow-blue-600/25 transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <span>BOOK A CONSULTATION</span>
            <ArrowUpRight className="w-4 h-4 text-blue-200" aria-hidden="true" />
          </button>

          {/* Secondary CTA */}
          <button
            onClick={handleExploreClick}
            className="w-full sm:w-auto px-6 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-[#0f141f] hover:bg-[#141b2b] border border-white/12 rounded-lg transition-all duration-200 whitespace-nowrap"
          >
            EXPLORE SERVICES
          </button>

          {/* Additional CTA: WhatsApp */}
          <button
            onClick={handleWhatsAppClick}
            className="w-full sm:w-auto px-5 py-3.5 text-sm font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-950/30 hover:bg-emerald-950/50 border border-emerald-500/25 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <MessageSquare className="w-4 h-4" aria-hidden="true" />
            <span>CHAT ON WHATSAPP</span>
          </button>

          {/* Additional CTA: Get a Quote */}
          <button
            onClick={handleQuoteClick}
            className="w-full sm:w-auto px-5 py-3.5 text-sm font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all duration-200 whitespace-nowrap"
          >
            GET A QUOTE
          </button>
        </div>

        {/* Scroll Indicator */}
        <a
          href="#about"
          className="mt-14 inline-flex flex-col items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
          aria-label="Scroll to about section"
        >
          <span className="tracking-wider uppercase text-[11px]">Discover Nexora</span>
          <ChevronDown className="w-4 h-4 animate-bounce" aria-hidden="true" />
        </a>

      </div>
    </section>
  );
};
